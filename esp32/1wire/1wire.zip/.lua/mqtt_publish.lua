--[[

This application shows how to create application that reads
temperature from DS18B20 sensor and publishes it to MQTT broker.
In this example OPCUA server is not used. Data are published
directly to MQTT broker.

]]

local ua = require("opcua.api")
local ds18b20Net = require("ds18b20")

local GPIO_PIN <const> = 4 -- GPIO pin where DS18B20 sensor is connected
local classId <const> = "6fa38ebb-44d2-a3ec-d251-1030c777f10a"
local dataTopic <const> = "rtl/json/data/urn:arykovanov-note:opcua:server/group/dataset"
local publisherId <const> = "test_manual_publisher"
local endpointUrl <const> = "opc.mqtt://test.mosquitto.org:1883"
local tranportProfileUri = ua.Types.TranportProfileUri.MqttJson

local mqttConfig <const> = {
  bufSize = 8192
}

local function searchDS18B20(net)
  local roms = {}
  trace(string.format("searchDS18B20 on %s", net))
  local cnt = 0
  for rom in net.bus:search() do
    local str = table.concat(rom)
    trace("Found rom", str)
    roms[str] = rom
    cnt = cnt + 1
  end

  trace(string.format("Found #%s roms", cnt))

  return roms
end

local roms
local mqttPublisher
local busy = 0

local function publishTemp(co)
  local net <close> = ds18b20Net(GPIO_PIN, co)

  trace("Called publish temp")
  busy = busy + 1
  if busy > 1 then
    trace("busy")
    busy = busy - 1
    return
  end

  if not roms then
    trace("Searing roms")

    local suc, roms = pcall(searchDS18B20, net)
    if not suc then
      trace("ERROR:", roms)
      return
    end
    trace("Search finished")

    -- Create MQTT publisher
    trace("Creating MQTT publisher", ua.newMqttClient)
    suc, mqttPublisher = pcall(ua.newMqttClient, mqttConfig)
    if not suc then
      trace("ERROR:", mqttPublisher)
      return
    end

    trace("Set MQTT fields")
    -- Create dataset with fields in MQTT message,
    -- Publisher will start listening of NodeID values changes in OPCUA server.
    local mqttFields = {}
    for romName, _ in pairs(roms) do
      mqttFields[rom] = {
        Name = romName,
      }
    end

    trace("Creating OPCUA PUBSUB dataset")
    mqttPublisher:createDataset(mqttFields, classId)

    trace("Connecting to ", endpointUrl)
    -- Connect to MQTT broker
    mqttPublisher:connect(endpointUrl, tranportProfileUri)
    trace("MQTT ready")
  end

  trace(string.format("Reading roms", #roms))

  for romName, rom in pairs(roms) do
    trace(string.format("Reading rom %s", romName))
    local temperature = net:readTemp(rom)
    trace("Temperature: ", temperature)
    trace(temperature, err)
    local secs, ns = ba.datetime("NOW"):ticks()
    secs = secs + ns / 1e9
    local value = {
      Value = { Float=temperature },
      ServerTimestamp = secs,
      StatusCode = ua.StatusCode.Good
    }

    trace("set field value")
    mqttPublisher:setValue(classId, romName, value)
  end

  trace("Publish values")
  mqttPublisher:publish(dataTopic, publisherId)
  trace("done")

  busy = busy - 1
end

local timer

local function readTemp()
    trace("mqtt_publish")
    if co then
      trace("coroutine already created")
      return
    end
    trace("creating coutine")
    local co = coroutine.create(publishTemp)
    trace("Starting publish coroutine")
    coroutine.resume(co, co)
    return true
  end

local function start()
  -- if timer then
    -- return
  -- end

  readTemp()
  -- timer = ba.timer(readTemp)
  -- timer:set(60000, true, true)
end

local function stop()
  -- timer:cancel()
end

return {
  start = start,
  stop = stop
}
ssssssssssssssssssssssssssssssssssssssssssss