local ua = require("opcua.api")
local Queue = require("opcua.binary.queue")
local socket = require("socket")
local Binary = require("opcua.binary.encode_types")

local tins = table.insert
local traceI = ua.trace.inf
local traceE = ua.trace.err
local traceD = ua.trace.dbg


local Srv = {}

local function getValueAttribute(id, val)
  return {
    nodeId = id,
    attributeId = ua.Types.AttributeId.Value,
    value = {
      value=val,
      statusCode = 0
    }
  }
end

function Srv:start(config, services)
  local infOn = config.logging.services.infOn
  local dbgOn = config.logging.services.dbgOn
  local errOn = config.logging.services.errOn

  if infOn then traceI("services | Starting server object") end
  self.Services = services
  -- Default namespace Array

  -- Server Status
  local status = {}
  status.startTime = socket.gettime()
  status.currentTime = socket.gettime()
  status.state = ua.Types.ServerState.Running

  status.buildInfo = {}
  status.buildInfo.productUri = ua.Version.ProductUri
  status.buildInfo.manufacturerName = ua.Version.ManufacturerName
  status.buildInfo.productName = ua.Version.ProductName
  status.buildInfo.softwareVersion = ua.Version.Version
  status.buildInfo.buildNumber = ua.Version.BuildNumber
  status.buildInfo.buildDate = socket.gettime()

  status.secondsTillShutdown = 0
  status.shutdownReason = {}

  local q = Queue.new(1024)
  local enc = Binary.Encoder.new(q)
  enc:serverStatusDataType(status)

  -- State structure
  local vServerStatus = {}
  vServerStatus.extensionObject = {}
  vServerStatus.extensionObject.typeId = "i=864" --ServerStatusDataType_Encoding_DefaultBinary
  vServerStatus.extensionObject.body = {}
  for _, val in ipairs(q) do
    tins(vServerStatus.extensionObject.body, val)
  end

  q:clear()
  enc:buildInfo(status.buildInfo)

  local vBuildInfo = {}
  vBuildInfo.extensionObject = {}
  vBuildInfo.extensionObject.typeId = "i=340" --BuildInfo_Encoding_DefaultBinary
  vBuildInfo.extensionObject.body = {}
  for _, val in ipairs(q) do
    tins(vBuildInfo.extensionObject.body, val)
  end

  q:clear()
  enc:samplingIntervalDiagnosticsDataType({
    samplingInterval = 100,
    monitoredItemCount = 0,
    maxMonitoredItemCount = 0,
    disabledMonitoredItemCount = 0
  })

  local vSampling = {
    typeId = "i=858", --  SamplingIntervalDiagnosticsDataType_Encoding_DefaultBinary,
    body = {}
  }
  for _, val in ipairs(q) do
    tins(vSampling.body, val)
  end


  q:clear()
  enc:serverDiagnosticsSummaryDataType({
      serverViewCount = 0,
      currentSessionCount = 0,
      cumulatedSessionCount = 0,
      securityRejectedSessionCount = 0,
      rejectedSessionCount = 0,
      sessionTimeoutCount = 0,
      sessionAbortCount = 0,
      currentSubscriptionCount = 0,
      cumulatedSubscriptionCount = 0,
      publishingIntervalCount = 0,
      securityRejectedRequestsCount = 0,
      rejectedRequestsCount = 0,
    })

  local vServerDiagnosticsSummary = {
    typeId = "i=861", -- ServerDiagnosticsSummaryDataType_Encoding_DefaultBinary,
    body = {}
  }
  for _, val in ipairs(q) do
    tins(vServerDiagnosticsSummary.body, val)
  end

  local nodes = {
    getValueAttribute("i=11314", {string={ua.Version.ProductUri}}), -- Server_ServerRedundancy_ServerUriArray
    getValueAttribute("i=3704", {extensionObject={ -- Server_ServerCapabilities_SoftwareCertificates
        typeId="i=7695", -- OpcUa_BinarySchema_SoftwareCertificate
        body={}
      }}
    ),

    -- Server_ServerArray
    getValueAttribute("i=2254", {string={ua.Version.ApplicationUri}}),
    -- Server_NamespaceArray =
    getValueAttribute("i=2255", {string={"http://opcfoundation.org/UA/"}}),

    -- Server_ServerStatus
    getValueAttribute("i=2256", vServerStatus),
    -- Server_ServerStatus_BuildInfo
    getValueAttribute("i=2260", vBuildInfo),
    -- Server_ServerStatus_BuildInfo_ProductName
    getValueAttribute("i=2261", {string=ua.Version.ProductName}),
    -- Server_ServerStatus_BuildInfo_ProductUri
    getValueAttribute("i=2262", {string=ua.Version.ProductUri}),
    -- Server_ServerStatus_BuildInfo_ManufacturerName
    getValueAttribute("i=2263", {string=ua.Version.ManufacturerName}),
    -- Server_ServerStatus_BuildInfo_SoftwareVersion
    getValueAttribute("i=2264", {string=ua.Version.Version}),
    -- Server_ServerStatus_BuildInfo_BuildNumber
    getValueAttribute("i=2265", {string=ua.Version.BuildNumber}),
    -- Server_ServerStatus_BuildInfo_BuildDate
    getValueAttribute("i=2266", {dateTime=status.buildInfo.buildDate}),
    -- Server_ServerStatus_StartTime
    getValueAttribute("i=2257", {dateTime=status.startTime}),
    -- Server_ServerStatus_State
    getValueAttribute("i=2259", {int32=ua.Types.ServerState.Running}),
    -- Server_ServerStatus_CurrentTime
    getValueAttribute("i=2258", {dateTime=socket.gettime()}),
    --Server_ServerStatus_SecondsTillShutdown
    getValueAttribute("i=2992", {uint32=0}),
    --Server_ServerStatus_ShutdownReason
    getValueAttribute("i=2993", {localizedText={text=""}}),

    -- Server_ServiceLevel
    getValueAttribute("i=2267", {byte=0}),  -- check what does it mean
    -- Server_Auditing
    getValueAttribute("i=2994", {boolean=false}),
    --Server_ServerCapabilities_ServerProfileArray
    getValueAttribute("i=2269", {string={ua.Types.ServerProfile.NanoEmbedded2017}  }),
    -- Server_ServerCapabilities_LocaleIdArray
    getValueAttribute("i=2271", {string={"en-US"}}),
    -- Server_ServerCapabilities_MinSupportedSampleRate
    getValueAttribute("i=2272", {double=0}),
    -- Server_ServerCapabilities_MaxBrowseContinuationPoints
    getValueAttribute("i=2735", {uint16=65535}),
    --Server_ServerCapabilities_MaxQueryContinuationPoints
    getValueAttribute("i=2736", {uint16=0}),
    -- Server_ServerCapabilities_MaxHistoryContinuationPoints
    getValueAttribute("i=2737", {uint16=0}),
    -- Server_ServerCapabilities_MaxArrayLength
    getValueAttribute("i=11702", {uint32=0xFFFFFFFF}),
    -- Server_ServerCapabilities_MaxStringLength
    getValueAttribute("i=11703", {uint32=0xFFFFFFFF}),
    -- Server_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall
    getValueAttribute("i=11714", {uint32=0});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerBrowse
    getValueAttribute("i=11710", {uint32=0xFFFFFFFF});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData
    getValueAttribute("i=12165", {uint32=0});
    --Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents
    getValueAttribute("i=12166", {uint32=0});
    --Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData
    getValueAttribute("i=12167", {uint32=0});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents
    getValueAttribute("i=12168", {uint32=0});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall
    getValueAttribute("i=11709", {uint32=0});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement
    getValueAttribute("i=11713", {uint32=0xFFFFFFFF});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerRead
    getValueAttribute("i=11705", {uint32=0xFFFFFFFF});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerWrite
    getValueAttribute("i=11707", {uint32=0xFFFFFFFF});
    -- Server_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes
    getValueAttribute("i=11711", {uint32=0xFFFFFFFF});
    --Server_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds
    getValueAttribute("i=11712", {uint32=0xFFFFFFFF});
    -- Server_ServerDiagnostics_EnabledFlag
    getValueAttribute("i=2294", {boolean=false}),

    -- Server_ServerDiagnostics_SamplingIntervalDiagnosticsArray
    getValueAttribute("i=2289", {extensionObject={vSampling}}),

    -- Server_ServerDiagnostics_ServerDiagnosticsSummary
    getValueAttribute("i=2275", {extensionObject=vServerDiagnosticsSummary}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount
    getValueAttribute("i=2276", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount
    getValueAttribute("i=2277", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount =
    getValueAttribute("i=2278", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount
    getValueAttribute("i=2279", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount
    getValueAttribute("i=2281", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount
    getValueAttribute("i=2282", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount
    getValueAttribute("i=2284", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount
    getValueAttribute("i=2285", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount
    getValueAttribute("i=2286", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount
    getValueAttribute("i=2287", {uint32=0}),
    -- Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount
    getValueAttribute("i=2288", {uint32=0}),
    --Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount
    getValueAttribute("i=3705", {uint32=0}),

    -- Server_ServerRedundancy_RedundancySupport
    getValueAttribute("i=3709", {uint32=0}),
    -- Server_ServerRedundancy_CurrentServerId
    getValueAttribute("i=11312", {string=""}),

-- getValueAttribute(Server_ServerRedundancy_RedundantServerArray, {}),

  --[[
    Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray = "i=3707",
    Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray = "i=3708",
    Server_ServerDiagnostics_SubscriptionDiagnosticsArray = "i=2290",
    Server_ServerDiagnostics_SessionsDiagnosticsSummary = "i=3706",
    Server_VendorServerInfo = "i=2295",
]]
  }

  if dbgOn then traceD("services | Saving server status in address space") end
  local results = services:write({nodesToWrite=nodes})

  local code = 0
  assert(#results.results == #nodes)
  for i,c in ipairs(results.results) do
    if c ~= 0 then
      if errOn then traceE(string.format("services | Node '%s' write finished with code 0x%X",nodes[i].nodeId,c)) end
      code = c
    end
  end

  if code ~= 0 then
    error(code)
  end

  -- Server_ServerStatus_CurrentTime = "i=2258"
  services:setVariableSource("i=2258", function() return { value = { dateTime = socket.gettime() } } end )
  if infOn then traceI("services | Server object started sucessfully") end
end

return Srv
