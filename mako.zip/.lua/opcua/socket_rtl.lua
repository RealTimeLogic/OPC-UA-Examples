local ua = require("opcua.api")
local s = ua.Status

local fmt = string.format

local traceD = ua.trace.dbg
local traceI = ua.trace.inf
local traceE = ua.trace.err

local function run(binaryServer, config)
  local infOn = config.logging.socket.infOn
  local errOn = config.logging.socket.errOn
  local dbgOn = config.logging.socket.dbgOn

  local Output = {
    send = function(self, data)
      if dbgOn then traceD(fmt("socket | %s sending %d bytes to client", self.sock, #data)) end
      local done, err = self.sock:write(data)
      if done == true then
        if dbgOn then traceD(fmt("socket | %s Data sent", self.sock)) end
      else
        if errOn then traceE(fmt("socket | %s Tcp error: %s", self.sock, err)) end
        error(s.BadCommunicationError)
      end
    end,
    receive = function(self)
        if dbgOn then traceD(fmt("socket | %s waiting for new data", self.sock)) end
        local data,err = self.sock:read()
        if err ~= nil then
          if dbgOn then traceD(fmt("socket | %s error %s", self.sock, err)) end
          error(s.BadCommunicationError)
        end
        if data == nil then
          if dbgOn then traceD(fmt("socket | %s nil data", self.sock)) end
          error(s.BadCommunicationError)
        end

        if dbgOn then traceD(fmt("socket | %s received %d bytes: ", self.sock, #data)) end
        return data
      end
  }
  Output.__index = Output
  local function newOutput(sock)
    local result = {
      sock = sock
    }
    setmetatable(result, Output)
    return result;
  end

  local function uaServerProc(clientSock)
    if infOn then traceI(fmt("socket | %s Accepted new connection", clientSock)) end
    -- clientSock:setoption("tcp-nodelay", true)

    local server = binaryServer:acceptConnection(newOutput(clientSock))
    while true do
      if dbgOn then traceD(fmt("socket | %s processing next message", clientSock)) end
      server:processData()
      -- local suc, code = pcall(server.processData, server)
      -- if not suc then
      --   if errOn then traceE(fmt("socket | %s error %s", clientSock, code)) end
      --   break
      -- end
    end

    if infOn then traceI(fmt("socket | %s Closing client socket.", clientSock)) end
    clientSock:close()
    if infOn then traceI(fmt("socket | %s Client socket closed.", clientSock)) end
  end

  -- A standard socket accept coroutine, accept new web clients.
  local function accept(srvSock)
     while true do
        local client = srvSock:accept()
        if not client then break end -- If server listen socket was closed.
        if infOn then traceI(fmt("socket | %s new client accepted", client)) end
        client:event(uaServerProc, "s") -- Activate the cosocket.
     end
  end

  if infOn then traceI(fmt("socket | Opening port '%d'", config.listenPort)) end
  local serverSock=ba.socket.bind(config.listenPort)
  if serverSock then
    if infOn then traceI(fmt("socket | %s created server socket.", serverSock, config.listenPort)) end
     serverSock:event(accept,"r")
    if infOn then traceI(fmt("socket | %s listening on port %d.", serverSock, config.listenPort)) end
  else
    if infOn then traceE("socket |Cannot open listen port!") end
  end
end

return run
