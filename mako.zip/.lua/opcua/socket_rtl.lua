local ua = require("opcua.api")
local s = ua.Status

local fmt = string.format

local traceI = ua.trace.inf
local traceE = ua.trace.err

local function run(binaryServer, config)
  local infOn = config.logging.socket.infOn
  local errOn = config.logging.socket.errOn
  local dbgOn = config.logging.socket.dbgOn

  local Output = {
    send = function(self, data, i, j)
      if dbgOn then traceI(fmt("socket | %s sending %d bytes to client", self.sock, #data)) end
      local done, err = self.sock:write(data, i, j)
      if done == true then
        if dbgOn then traceI(fmt("socket | %s Data sent", self.sock)) end
        return
      end
      if errOn then traceE(fmt("socket | %s Tcp error: ", self.sock, err)) end
      error(s.BadCommunicationError)
    end
  }
  Output.__index = Output
  local function newOutput(sock)
    local result = {
      sock = sock
    }
    setmetatable(result, Output)
    return result;
  end

  local function uaServerProc(clientSock)
    if infOn then traceI("socket | %s Accepted startingto process client", clientSock) end

    local suc, code = pcall(binaryServer.addConnection, binaryServer, clientSock, newOutput(clientSock))
    if not suc then
      if errOn then traceE(fmt("socket | %s Failed to add connection: %s", clientSock, code)) end
      return
    end

    while true do
      if dbgOn then traceI(fmt("socket | %s reading data", clientSock)) end
      local data, err = clientSock:read()
      if err ~= nil then
        if errOn then traceE(fmt("socket | %s read error: %s.", clientSock, err)) end
        break
      end

      if dbgOn then traceI(fmt("socket | %s Received %d bytes", clientSock, #data)) end
      suc, code = pcall(binaryServer.push, binaryServer, clientSock, data)
      if not suc then
        if errOn then traceE(fmt("socket | %s Error data processing 0x%s", clientSock, code)) end
        break
      end
    end

    if infOn then traceI(fmt("socket | %s removing client connection.", clientSock)) end
    binaryServer:removeConnection(clientSock)
    if infOn then traceI(fmt("socket | %s Client connection removed.", clientSock)) end
  end

  -- A standard socket accept coroutine, accept new web clients.
  local function accept(srvSock)
     while true do
        local client = srvSock:accept()
        if not client then break end -- If server listen socket was closed.
        if infOn then traceI(fmt("socket | %s new client accepted", client)) end
        client:event(uaServerProc,"r") -- Activate the cosocket.
     end
  end

  if infOn then traceI(fmt("socket | Opening port '%d'", config.listenPort)) end
  local serverSock=ba.socket.bind(config.listenPort)
  if serverSock then
    if infOn then traceI(fmt("socket | %s created server socket.", serverSock, config.listenPort)) end
     serverSock:event(accept,"r")
    if infOn then traceI(fmt("socket | %s listening on port %d.", serverSock, config.listenPort)) end
  else
    if infOn then traceE("socket |Cannot open listen port!") end
  end
end

return run
