local socket = require("socket")
local s = require("opcua.status_codes")

local BadCommunicationError = s.BadCommunicationError

local ua = require("opcua.api")

local trm = table.remove
local tins = table.insert
local fmt = string.format
local traceI = ua.trace.inf
local traceE = ua.trace.err


local Output = {
  send = function(self, data, i, j)
    local infoOn = self.trace.infOn
    if infoOn then traceI(fmt("socket | %s waiting socket ready to send data", self.sock)) end
    socket.select(nil, {self.sock})
    if infoOn then traceI(fmt("socket | %s Sending to client %d bytes", self.sock, #data)) end
    local sent,err = self.sock:send(data, i, j)
    if err ~= nil then
      if self.trace.errOn then traceE(fmt("socket | %s TCP error: %s", self.sock, err)) end
      error(BadCommunicationError)
    end
    if sent ~= #data then
      if self.trace.errOn then traceE(fmt("socket | %s TCP error: sent %d bytes of %d", self.sock, sent, #data)) end
      error(BadCommunicationError)
    end
    if infoOn then traceI(fmt("socket | %s Data sent to client", self.sock)) end
  end
}
Output.__index = Output

local function newOutput(config, sock)
  local result = {
    config = config,
    trace = config.logging.socket,
    sock = sock,
  }
  setmetatable(result, Output)
  if result.trace.infOn then traceI(fmt("socket | %s created", result.sock)) end
  return result;
end

local function closeSocket(config, socks, sock)
  local infOn = config.logging.socket.infOn
  if infOn then traceI(fmt("socket | %s Shutdown socket", sock)) end
  sock:shutdown()
  if infOn then traceI(fmt("socket | %s Closing socket", sock)) end
  sock:close()
  for i = 1,#socks do
    if socks[i] == sock then
      trm(socks, i)
      break
    end
  end
  if infOn then traceI(fmt("socket | %s Socket closed", sock)) end
end


local function run(binaryServer, config)
  local listen = assert(socket.bind(config.listenAddress, config.listenPort))
  local socks = {listen}
  local infOn = config.logging.socket.infOn
  local errOn = config.logging.socket.errOn

  while true do
    if infOn then traceI("socket | select socket") end
    local ready = socket.select(socks)
    for _,sock in ipairs(ready) do
      if infOn then traceI(fmt("socket | %s ready", sock)) end
      if sock == listen then
        if infOn then traceI(fmt("socket | %s Accepted new connection", sock)) end
        local client = listen:accept()
        client:settimeout(0)
        binaryServer:addConnection(client, newOutput(config, client))
        tins(socks, client)
      else
        local data,err,part = sock:receive("*a")
        local code
        local suc
        if err == nil then
            if infOn then traceI(fmt("socket | %s Received %d bytes", sock, #data)) end
            suc, code = pcall(binaryServer.push, binaryServer, sock, data)
        else
          if err == "timeout" then
            if infOn then traceI(fmt("socket | %s Received %d bytes", sock, #part)) end
            suc, code = pcall(binaryServer.push, binaryServer, sock, part)
          else
            if errOn then traceE(fmt("socket | %s read error '%s'", sock, err)) end
          end
        end

        if err == 'closed' or not suc or code ~= s.Good then
          if infOn then traceI(fmt("socket | %s Closing socket", sock)) end
          closeSocket(config, socks, sock)
          binaryServer:removeConnection(sock)
        end
      end
    end
  end
end


return run
