local Connections = require("opcua.binary.server_connection")
local ua = require("opcua.api")
local s = ua.Status

local S = {}
S.__index = S

function S:addConnection(conn, out)
  if self.trace.infOn then ua.trace.inf("binary | new connection accepted") end
  assert(conn ~= nil)
  assert(self.connections[conn] == nil)
  assert(out ~= nil and out.send ~= nil)
  self.connections[conn] = Connections.new(self.config, self.services, out)
  return s.Good
end

function S:removeConnection(conn)
  if self.trace.infOn then ua.trace.inf("binary | Connection closed") end
  assert(self.connections[conn] ~= nil)
  self.connections[conn] = nil
  return s.Good
end

function S:push(conn, data)
  local channel = self.connections[conn]
  assert(channel ~= nil)
  return channel:push(data)
end

local function newServer(config, services)
  assert(config ~= nil)
  assert(services ~= nil)

  if config.logging.binary.infOn then
    ua.trace.inf("binary: Creating new endpoint '"..config.endpointUrl.."'")
  end

  local srv = {
    config = config,
    trace = config.logging.binary,
    services = services,
    connections = {},
    channelId = 0,
  }

  setmetatable(srv, S)
  return srv
end

return {new=newServer}
