local ua = require("opcua.api")
local tools = require("opcua.binary.tools")
local socket = require("socket")
local Q = require("opcua.binary.queue")
local MessageEncoder = require("opcua.binary.messages_encode")
local MessageDecoder = require("opcua.binary.messages_decode")

local tins = table.insert

local C={} -- OpcUa Client
C.__index=C

function C:helloServer(endpoint)
  local hello = {
    protocolVersion = 0,
    receiveBufferSize = self.config.bufSize,
    sendBufferSize = self.config.bufSize,
    maxMessageSize = self.config.bufSize,
    maxChunkCount = 0,
    endpointUrl = endpoint
  }
  self.enc:hello(hello)

  local ack = self.dec:acknowledge()
  if hello.sendBufferSize ~= ack.receiveBufferSize then
    self.dec.q = Q.new(ack.receiveBufferSize)
  end
  if hello.receiveBufferSize ~= ack.sendBufferSize then
    self.dec.q = Q.new(ack.sendBufferSize)
  end

  return ack
end

function C:openSecureChannel(securityParams)
  self.enc:openSecureChannelRequest(self:nextOpenRequestParams(), securityParams)

  local resp = self.dec:openSecureChannelResponse()
  local response = resp.openSecureChannelResponse

  local code = response.responseHeader.serviceResult
  if code ~= 0 then error(code) end

  self.channelId = response.securityToken.channelId

  self.enc.chunks.channelId = response.securityToken.channelId
  self.enc.chunks.secureHeader.tokenId = response.securityToken.tokenId

  self.enc.securityPolicy = securityParams.securityPolicy
  self.enc.certificate = securityParams.certificate
  self.enc.certificateThumbprint = securityParams.certificateThumbprint

  return response
end

function C:closeSecureChannel()
  return self.enc:closeSecureChannelRequest(self:nextOpenRequestParams())
end

function C:findServers(serversParams)
  self.enc:findServersRequest(self:nextRequestParams(), serversParams)
  local resp = self.dec:findServersResponse()
  return resp.findServersResponse.servers
end

function C:getEndpoints(endpointParams)
  self.enc:getEndpointsRequest(self:nextRequestParams(), endpointParams)

  local resp = self.dec:getEndpointsResponse()
  resp = resp.getEndpointsResponse
  local response = {}

  for _,endpoint in ipairs(resp.endpoints) do
    local res = {}

    res.serverCertificate = endpoint.serverCertificate
    res.securityMode = endpoint.securityMode
    res.securityPolicyUri = endpoint.securityPolicyUri
    res.server = {}
    res.server.applicationUri = endpoint.server.applicationUri
    res.server.productUri = endpoint.server.productUri
    res.server.applicationType = endpoint.server.applicationType
    res.server.gatewayServerUri = endpoint.server.gatewayServerUri
    res.server.discoveryProfileUri = endpoint.server.discoveryProfileUri

    res.server.applicationName = {}
    if endpoint.server.applicationName.locale ~= nil then
      res.server.applicationName.locale = endpoint.server.applicationName.locale
    end

    if endpoint.server.applicationName.text ~= nil then
      res.server.applicationName.text = endpoint.server.applicationName.text
    end

    res.server.discoveryUrls = {}
    if endpoint.server.discoveryUrls ~= nil then
      for _,url in ipairs(endpoint.server.discoveryUrls) do
        tins(res.server.discoveryUrls, url)
      end
    end

    res.userIdentityTokens = {}
    for _,policy in ipairs(endpoint.userIdentityTokens) do
      tins(res.userIdentityTokens, {
          policyId = policy.policyId,
          tokenType = policy.tokenType,
          issuedTokenType = policy.issuedTokenType,
          issuerEndpointUrl = policy.issuerEndpointUrl,
          securityPolicyUri = policy.securityPolicyUri

      })
    end
    res.transportProfileUri = endpoint.transportProfileUri
    res.securityLevel = endpoint.securityLevel

    tins(response, res)
  end

  return response
end


function C:createSession(sessionParams)
  self.enc:createSessionRequest(self:nextRequestParams(), sessionParams)

  local resp= self.dec:createSessionResponse()
  local response = {
    sessionId = resp.createSessionResponse.sessionId,
    maxRequestMessageSize = resp.createSessionResponse.maxRequestMessageSize,
    authenticationToken = resp.createSessionResponse.authenticationToken,
    revisedSessionTimeout = resp.createSessionResponse.revisedSessionTimeout,
    serverNonce = resp.createSessionResponse.serverNonce,
    serverCertificate = resp.createSessionResponse.serverCertificate
  }
  return response
end

function C:activateSession(sessionParams)
  self.enc:activateSessionRequest(self:nextRequestParams(), sessionParams)

  local resp = self.dec:activateSessionResponse()
  local response = {
    activationResultCodes = resp.activateSessionResponse.results
  }
  return response
end

function C:closeSession(closeParams)
  self.enc:closeSessionRequest(self:nextRequestParams(), closeParams)
  return self.dec:closeSessionResponse()
end

function C:browse(browseParams)
  self.enc:browseRequest(self:nextRequestParams(), browseParams)

  local resp = self.dec:browseResponse()
  local results = {}

  for _,result in ipairs(resp.browseResponse.results) do
    local res = {
      statusCode = result.statusCode,
      continuationPoint = result.continuationPoint
    }

    local refs = {}
    for _, reference in ipairs(result.references) do
      local ref = {
        referenceTypeId = reference.referenceTypeId,
        isForward = reference.isForward,
        nodeId = reference.nodeId,
        browseName = {
          ns = reference.browseName.ns,
          name = reference.browseName.name
        },
        nodeClass = reference.nodeClass,
        typeDefinition = reference.typeDefinition
      }
      tins(refs, ref)
    end
    res.references = refs
    tins(results, res)
  end

  return results
end

function C:read(nodes)
  self.enc:readRequest(self:nextRequestParams(), nodes)
  local resp = self.dec:readResponse()
  return resp.readResponse.results
end

function C:write(nodes)
  self.enc:writeRequest(self:nextRequestParams(), nodes)
  local resp = self.dec:writeResponse()
  return resp.writeResponse.results
end

function C:createSubscription(nodes)
  self.enc:createSubscriptionRequest(self:nextRequestParams(), nodes)
  local resp = self.dec:createSubscriptionResponse()
  return resp.createSubscriptionResponse
end



function C:translateBrowsePaths(browsePaths)
  self.enc:translateBrowsePathsToNodeIdsRequest(self:nextRequestParams(), browsePaths)
  local resp = self.dec:translateBrowsePathsToNodeIdsResponse()
  return resp.translateBrowsePathsToNodeIdsResponse.results
end

function C:addNodes(nodesToAdd)
  self.enc:addNodesRequest(self:nextRequestParams(), nodesToAdd)
  local resp = self.dec:addNodesResponse()
  return resp.addNodesResponse.results
end

function C:nextRequestParams()
  self.requestHandle = self.requestHandle + 1
  return {
    requestId = self.requestHandle,
    requestHandle = self.requestHandle,
    requestTimeout = 1000,
    requestCreatedAt = socket.gettime(),
    sessionAuthToken = self.sessionAuthToken,
  }
end


function C:nextOpenRequestParams()
  self.requestHandle = self.requestHandle + 1
  return {
    securityPolicy = self.securityPolicy,
    certificate = self.certificate,
    certificateThumbprint = self.certificateThumbprint,
    requestId = self.requestHandle,
    requestHandle = self.requestHandle,
    requestTimeout = 1000,
    requestCreatedAt = socket.gettime(),
    sessionAuthToken = self.sessionAuthToken,
  }
end


function C:sendData()
  local data = tools.makeString(self.enc.dataQ)
  self.enc.dataQ:clear()
  self.sock:send(data)
end

local function new(config, sock)
  assert(config ~= nil)
  assert(sock ~= nil)

  local client = {
    sock = sock,
    config = config,
    enc = MessageEncoder.new(config, sock),
    dec = MessageDecoder.new(config.bufSize, sock),
    requestHandle = 0,
    sessionAuthToken = ua.NodeId.Null,
    securityPolicy = ua.Types.SecurityPolicy.None,
    certificate = nil,
    certificateThumbprint = nil,
  }

  setmetatable(client, C)
  return client
end

return {new=new}
