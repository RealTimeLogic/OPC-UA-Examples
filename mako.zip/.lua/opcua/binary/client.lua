local ua = require("opcua.api")
local tools = require("opcua.binary.tools")
local socket = require("socket")
local MessageEncoder = require("opcua.binary.chunks_encode")
local MessageDecoder = require("opcua.binary.chunks_decode")
local MessageId = require("opcua.binary.message_id")

local tins = table.insert

local C={} -- OpcUa Client
C.__index=C


local function ensureOK(resp)
  local code = resp.responseHeader.serviceResult
  if code ~= 0 then
    error(code)
  end
end

function C:helloServer(endpoint)
  local hello = {
    protocolVersion = 0,
    receiveBufferSize = self.config.bufSize,
    sendBufferSize = self.config.bufSize,
    maxMessageSize = self.config.bufSize,
    maxChunkCount = 0,
    endpointUrl = endpoint
  }
  self.enc:hello(hello)

  local ack = self.dec:acknowledge()
  self.dec:setBuferSize(ack.sendBufferSize)
  self.enc:setBuferSize(ack.receiveBufferSize)
  self.enc:setChannelId(0)
  return ack
end

function C:openSecureChannel(channelParams)
  local request = self.enc:createRequest(self:nextRequestParams())
  request.clientProtocolVersion = 0
  request.requestType = channelParams.requestType
  request.securityMode = channelParams.securityMode
  request.clientNonce = channelParams.clientNonce
  request.requestedLifetime = channelParams.requestedLifetime

  self.enc:message(MessageId.OPEN_SECURE_CHANNEL_REQUEST, request)

  local resp = self.dec:message()
  local response = resp.body
  ensureOK(response)

  self.enc:setChannelId(response.securityToken.channelId)
  self.enc:setTokenId(response.securityToken.tokenId)

  return response
end

function C:closeSecureChannel()
  self.enc:message(MessageId.CLOSE_SECURE_CHANNEL_REQUEST, self.enc:createRequest(self:nextOpenRequestParams()))
end

function C:findServers(serversParams)
  local request = self.enc:createRequest(self:nextOpenRequestParams())
  request.endpointUrl = serversParams.endpointUrl
  request.localeIds = {}
  request.serverUris = {}

  self.enc:message(MessageId.FIND_SERVERS_REQUEST, request)
  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body.servers
end

function C:getEndpoints(params)
  local request = self.enc:createRequest(self:nextRequestParams())
  request.endpointUrl = params.endpointUrl
  request.localeIds = {}
  request.profileUris = {}
  self.enc:message(MessageId.GET_ENDPOINTS_REQUEST, request)

  local resp = self.dec:message()
  resp = resp.body
  ensureOK(resp)
  local response = {}

  for _,endpoint in ipairs(resp.endpoints) do
    local res = {}

    res.endpointUrl = endpoint.endpointUrl
    res.serverCertificate = endpoint.serverCertificate
    res.securityMode = endpoint.securityMode
    res.securityPolicyUri = endpoint.securityPolicyUri
    res.server = {}
    res.server.applicationUri = endpoint.server.applicationUri
    res.server.productUri = endpoint.server.productUri
    res.server.applicationType = endpoint.server.applicationType
    res.server.gatewayServerUri = endpoint.server.gatewayServerUri
    res.server.discoveryProfileUri = endpoint.server.discoveryProfileUri

    res.server.applicationName = {}
    if endpoint.server.applicationName.locale ~= nil then
      res.server.applicationName.locale = endpoint.server.applicationName.locale
    end

    if endpoint.server.applicationName.text ~= nil then
      res.server.applicationName.text = endpoint.server.applicationName.text
    end

    res.server.discoveryUrls = {}
    if endpoint.server.discoveryUrls ~= nil then
      for _,url in ipairs(endpoint.server.discoveryUrls) do
        tins(res.server.discoveryUrls, url)
      end
    end

    res.userIdentityTokens = {}
    for _,policy in ipairs(endpoint.userIdentityTokens) do
      tins(res.userIdentityTokens, {
          policyId = policy.policyId,
          tokenType = policy.tokenType,
          issuedTokenType = policy.issuedTokenType,
          issuerEndpointUrl = policy.issuerEndpointUrl,
          securityPolicyUri = policy.securityPolicyUri

      })
    end
    res.transportProfileUri = endpoint.transportProfileUri
    res.securityLevel = endpoint.securityLevel

    tins(response, res)
  end

  return response
end


function C:createSession(sessionParams)
  local request = self.enc:createRequest(self:nextRequestParams())
  request.clientDescription = {
      applicationUri = sessionParams.applicationUri,
      productUri = sessionParams.productUri,
      applicationName = {
        text = sessionParams.applicationName
      },
      applicationType = sessionParams.applicationType,
      gatewayServerUri = nil,
      discoveryProfileUri = nil,
      discoveryUrls = {},
    }
  request.serverUri = sessionParams.serverUri
  request.endpointUrl = sessionParams.endpointUrl
  request.sessionName = sessionParams.sessionName
  request.clientNonce = sessionParams.clientNonce
  request.clientCertificate = sessionParams.clientCertificate
  request.requestedSessionTimeout = sessionParams.sessionTimeout
  request.maxResponseMessageSize = 0

  self.enc:message(MessageId.CREATE_SESSION_REQUEST, request)

  local msg = self.dec:message()
  local resp = msg.body
  ensureOK(resp)
  return resp
end

function C:activateSession(sessionParams)
  local request = self.enc:createRequest(self:nextRequestParams(), sessionParams)
  self.enc:message(MessageId.ACTIVATE_SESSION_REQUEST, request)

  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body
end

function C:closeSession(closeParams)
  local request = self.enc:createRequest(self:nextRequestParams(), closeParams)
  self.enc:message(MessageId.CLOSE_SESSION_REQUEST, request)
  local res = self.dec:message()
  ensureOK(res.body)
  return res
end

function C:browse(browseParams)
  local request = self.enc:createRequest(self:nextRequestParams())
  request.nodesToBrowse = browseParams.nodesToBrowse
  if browseParams.requestedMaxReferencesPerNode ~= nil then
    request.requestedMaxReferencesPerNode = browseParams.requestedMaxReferencesPerNode
  else
    request.requestedMaxReferencesPerNode = 1000
  end

  if browseParams.view ~= nil then
    request.view = {
      viewId = browseParams.view,
      timestamp = browseParams.view.timestamp,
      viewVersion = browseParams.view.version
    }
  else
    request.view = {
      viewId = ua.NodeId.Null,
      timestamp = nil, -- not specified ~1600 year
      viewVersion = 0
    }
  end

  self.enc:message(MessageId.BROWSE_REQUEST, request)

  local msg = self.dec:message()
  ensureOK(msg.body)
  local results = {}

  for _,result in ipairs(msg.body.results) do
    local res = {
      statusCode = result.statusCode,
      continuationPoint = result.continuationPoint
    }

    local refs = {}
    for _, reference in ipairs(result.references) do
      local ref = {
        referenceTypeId = reference.referenceTypeId,
        isForward = reference.isForward,
        nodeId = reference.nodeId,
        browseName = {
          ns = reference.browseName.ns,
          name = reference.browseName.name
        },
        nodeClass = reference.nodeClass,
        typeDefinition = reference.typeDefinition
      }
      tins(refs, ref)
    end
    res.references = refs
    tins(results, res)
  end

  return results
end

function C:read(nodes)
  local request = self.enc:createRequest(self:nextRequestParams(), nodes)
  self.enc:message(MessageId.READ_REQUEST, request)
  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body.results
end

function C:write(nodes)
  local request = self.enc:createRequest(self:nextRequestParams(), nodes)
  self.enc:message(MessageId.WRITE_REQUEST, request)
  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body.results
end

function C:createSubscription(sub)
  local request = self.enc:createRequest(self:nextRequestParams(), sub)
  self.enc:message(MessageId.CREATE_SUBSCRIPTION_REQUEST, request)
  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body
end



function C:translateBrowsePaths(browsePaths)
  local request = self.enc:createRequest(self:nextRequestParams(), browsePaths)
  self.enc:message(MessageId.TRANSLATE_BROWSE_PATHS_TO_NODE_IdS_REQUEST, request)
  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body.results
end

function C:addNodes(nodesToAdd)
  local request = self.enc:createRequest(self:nextRequestParams(), nodesToAdd)
  self.enc:message(MessageId.ADD_NODES_REQUEST, request)
  local resp = self.dec:message()
  ensureOK(resp.body)
  return resp.body.results
end

function C:nextRequestParams()
  self.requestHandle = self.requestHandle + 1
  return {
    requestId = self.requestHandle,
    requestHandle = self.requestHandle,
    requestTimeout = 1000,
    requestCreatedAt = socket.gettime(),
    sessionAuthToken = self.sessionAuthToken,
  }
end


function C:nextOpenRequestParams()
  self.requestHandle = self.requestHandle + 1
  return {
    requestId = self.requestHandle,
    requestHandle = self.requestHandle,
    requestTimeout = 1000,
    requestCreatedAt = socket.gettime(),
    sessionAuthToken = self.sessionAuthToken,
    securityPolicy = self.securityPolicy,
    certificate = self.certificate,
    certificateThumbprint = self.certificateThumbprint,
  }
end


function C:sendData()
  local data = tools.makeString(self.enc.dataQ)
  self.enc.dataQ:clear()
  self.sock:send(data)
end

local function new(config, sock)
  assert(config ~= nil)
  assert(sock ~= nil)

  local client = {
    sock = sock,
    config = config,
    enc = MessageEncoder.new(config, sock),
    dec = MessageDecoder.new(config, sock),
    requestHandle = 0,
    sessionAuthToken = ua.NodeId.Null,
    securityPolicy = ua.Types.SecurityPolicy.None,
    certificate = nil,
    certificateThumbprint = nil,
  }

  setmetatable(client, C)
  return client
end

return {new=new}
