local socket = require("socket")

local ME = require("opcua.binary.messages_encode")
local MD = require("opcua.binary.server_connection_decode")
local Msg = require("opcua.binary.message_id")
local ua = require("opcua.api")
local HeaderType = require("opcua.binary.encode_types").HeaderType -- TODO Eliminate
local ChunkType = require("opcua.binary.encode_types").ChunkType -- TODO Eliminate
local tools = require("opcua.binary.tools")

local s = ua.Status
local trace = ua.trace
local fmt = string.format
local traceD = ua.trace.dbg
local traceE = ua.trace.err
local traceI = ua.trace.inf


local S = {}
S.__index = S

local tokenNum = 1
local function genNextToken()
  tokenNum = tokenNum + 1
  return tokenNum
end

local channelsNum = os.time()
local HeaderSize = 8

local State = {
  New = 0,    -- just accepted connection.
  Hello = 1,  -- client received acknowledge on hello message.
  Open = 2,   -- client opened secure channel and can send messages.
  Closed = 4, -- client caused error and connection was closed.
}

function S:send(data, i, j)
  local dbgOn = self.config.logging.socket.dbgOn
  if dbgOn then
    traceD("socket | ------------ SENDING DATA ----------------")
    tools.hexPrint(data, function(msg) traceD("socket | "..msg) end)
    traceD("socket | ------------------------------------------")
  end

  self.out:send(data, i, j)
end

function S:push(data)
  local dbgOn = self.trace.dbgOn
  local errOn = self.trace.errOn

  if dbgOn then traceD(fmt("%s new data received", self.logId)) end

  if self.config.logging.socket.dbgOn  then
    traceD("socket | ------------ NEW DATA RECEIVED----------------")
    tools.hexPrint(data, function(msg) traceD("socket | "..msg) end)
    traceD("socket | ----------------------------------------------")
  end

  self.decoder.dataQ:pushBack(data) -- TODO it is possible overflow here:  we can receive several messages in a row
  if #self.decoder.dataQ < HeaderSize then
    if dbgOn then traceD(fmt("%s Recevied data less than header. Waiting more..", self.logId)) end
    return -- continue to wait new data
  end
  local header = self.decoder:messageHeader()
  if header.messageSize > #self.decoder.dataQ + HeaderSize then
    if dbgOn then traceD(fmt("%s MessageSize(%d) > #data(%d). Waiting more data", self.logId, header.messageSize, #data)) end
    return
  end

  if header.chunk == ChunkType.Intermediate then
    if errOn then traceE(fmt("%s Intermediate chunks not supported.", self.logId)) end
    -- TODO: Chunked messages not implemented
    error(s.BadNotImplemented)
  elseif header.chunk == ChunkType.Abort then
    if errOn then traceE(fmt("%s Received ABORT message from client.", self.logId)) end
    error(s.BadTcpMessageTypeInvalid)
  elseif header.chunk ~= ChunkType.Final then
    if errOn then traceE(fmt("%s Unknown chunk type '%s'", self.logId, header.chunk)) end
    error(s.BadDecodingError)
  end

  if header.type == HeaderType.Hello then
    self:processHello()
  elseif header.type == HeaderType.Open then
    self:processOpenSecureChannel()
  elseif header.type == HeaderType.Close then
    self:processCloseSecureChannel()
  elseif header.type == HeaderType.Message then
    self:processMessage()
  else
    if errOn then traceE(fmt("%s Unknown message type '%s'", self.logId, header.type)) end
    error(s.BadTcpMessageTypeInvalid)
  end

  if dbgOn then traceD(fmt("%s data processed", self.logId)) end
end

function S:processHello()
  local dbgOn = self.trace.dbgOn
  local errOn = self.trace.errOn
  local infOn = self.trace.infOn

  if dbgOn then traceD(fmt("%s Processing HEL", self.logId)) end
  if self.state ~= State.New then
    if errOn then trace.E(fmt("%s Channel already HELLO'ed", self.logId)) end
    error(s.BadTcpMessageTypeInvalid)
  end

  if dbgOn then traceD(fmt("%s decoding hello message", self.logId)) end
  local hello = self.decoder:hello()
  if infOn then traceI(fmt("%s Received Hello: EndpointUrl='%s' SendBufferSize=%d, ReceiveBufferSize=%d", self.logId, hello.endpointUrl, hello.sendBufferSize, hello.receiveBufferSize)) end

  -- Endpoint URLs are used in proxy servers
  if hello.endpointUrl ~= nil and self.services.hello ~= nil then
    if dbgOn then traceD(fmt("%s Pass HEL to Services", self.logId)) end
    self.services:hello(hello.endpointUrl)
  end

  local bufSize = math.min(self.config.bufSize, hello.receiveBufferSize)
  local messageSize = 1 << 20 -- 1MB
  local maxChunkCount = messageSize / bufSize

  if self.decoder.dataQ:capacity() ~= hello.sendBufferSize then
    self.decoder = MD.new(bufSize)
  end
  if self.encoder.chunks.bufSize ~= hello.receiveBufferSize then
    local chunksParams = {
      bufSize = bufSize,
      securityPolicyUri = self.securityPolicyUri
    }
    self.encoder = ME.new(self.config, self, chunksParams)
    self.encoder.chunks.channelId = self.channelId
  end

  local ack = {
    protocolVersion = 0,
    receiveBufferSize = bufSize,
    sendBufferSize = bufSize,
    maxMessageSize = messageSize,
    maxChunkCount = maxChunkCount
  }

  if infOn then
    traceI(fmt("%s Acknowledge: ReceiveBufferSize=%d, SendBufferSize=%d, MaxMessageSize=%d, MaxChunkCount=%d",
        self.logId, ack.receiveBufferSize, ack.sendBufferSize, ack.maxMessageSize, ack.maxChunkCount))
  end

  self.encoder:acknowledge(ack)
  self.state = State.Hello
  if infOn then traceI(fmt("%s Connection Acknowledged", self.logId)) end
end


function S:processOpenSecureChannel()
  local dbgOn = self.trace.dbgOn
  local errOn = self.trace.errOn
  local infOn = self.trace.infOn

  if dbgOn then traceD(fmt("%s OpenSecureChannel", self.logId)) end
  local msg = self.decoder:openSecureChannelRequest()
  local req = msg.openSecureChannelRequest

  if self.state == State.New then
    if errOn then traceE(fmt("%s Failed to open secure channel: Client didn't send hello", self.logId)) end
    self:responseServiceFault(msg, req.requestHeader, s.BadRequestTypeInvalid)
    return
  elseif self.state == State.Hello then
    if req.requestType ~= ua.Types.SecurityTokenRequestType.Issue then
      if errOn then traceE(fmt("%s Received request type '%s' instead 'issue(0)'", self.logId, req.requestType)) end
      self:responseServiceFault(msg, req.requestHeader, s.BadRequestTypeInvalid)
      return
    end
    if infOn then traceI(fmt("%s Issuing new channel token", self.logId)) end
  elseif self.state == State.Open then
    if req.requestType ~= ua.Types.SecurityTokenRequestType.Renew then
      if errOn then traceE(fmt("%s Received request type '%s' instead 'renew(1)'", self.logId, req.requestType)) end
      self:responseServiceFault(msg, req.requestHeader, s.BadRequestTypeInvalid)
      return
    end
    if infOn then traceI(fmt("%s Renew channel token", self.logId)) end
  elseif self.state == State.Closed then
    if errOn then traceE(fmt("%s Failed to renew closed channel", self.logId)) end
    self:responseServiceFault(msg, req.requestHeader, s.BadSecureChannelClosed)
    return
  else
    if errOn then traceE(fmt("Internal errror: Secure channel %d is in invalid state: %d", self.logId, self.state)) end
    error(s.BadInternalError)
  end

  if dbgOn then traceD(fmt("%s Pass open secure channel to services", self.logId)) end
  self.services:openSecureChannel(req)

  local responseParams = {
    channelId = self.channelId,
    requestId = msg.sequenceHeader.requestId,
    securityPolicy = msg.secureHeader.securityPolicyUri,
    sertificate = self.sertificate,
    sertificateThumbprint = self.sertificateThumbprint,
    requestHandle = req.requestHeader.requestHandle,
    requestCreatedAt = socket.gettime(),
    serviceResult = s.Good,
  }

  local tokenId = genNextToken()
  local createdAt = socket.gettime()
  local lifeTime = msg.openSecureChannelRequest.requestedLifetime -- ms
  if lifeTime <= 1000 then
    lifeTime = 1000
  elseif lifeTime > 300000 then
    lifeTime = 300000
  end

  self.tokens[tokenId] = {
    createdAt = createdAt,
    cifeTime = lifeTime,
    expiresAt = createdAt + lifeTime / 1000
  }

  local secureChannelParams = {
    channelId = self.channelId,
    channelTokenId = tokenId,
    channelCreatedAt = createdAt,
    revisedLifetime = lifeTime,
    serverNonce = "\1\2\3\4\5\6\7\8\9\0\1\2\3\4\5\6\7\8\9\0\1\2"
  }

  if dbgOn then traceD(fmt("%s Response for OpenSecureChannel", self.logId)) end
  self.encoder:openSecureChannelResponse(responseParams, secureChannelParams)
  self.state = State.Open
  self:cleanupExpredTokens(createdAt)
  if infOn then traceI(fmt("%s Issued secure channel token %s lifetime %s", self.logId, tokenId, lifeTime)) end
end

function S:processCloseSecureChannel()
  local dbgOn = self.trace.dbgOn
  local errOn = self.trace.errOn
  local infOn = self.trace.infOn

  if infOn then traceI(fmt("%s processing CloseSecureChannel", self.logId)) end
  if self.state ~= State.Open then
    if errOn then traceE(fmt("%s Client didn't open channel", self.logId)) end
  else
    if dbgOn then traceD(fmt("%s Pass close secure channel to services", self.logId)) end
    self.services:closeSecureChannel(self.channelId)
  end

  self.state = State.Closed
  if infOn then traceI(fmt("%s Secure channel closed", self.logId)) end
  error(s.BadSecureChannelClosed)
end

function S:processMessage()
  local dbgOn = self.trace.dbgOn
  local errOn = self.trace.errOn

  local msg = self.decoder:secureMessageHeader()
  msg.secureHeader = self.decoder:symmetricSecurityHeader()
  msg.sequenceHeader = self.decoder:sequenceHeader()
  msg.requestId = self.decoder:requestId()

  if self.state ~= State.Open then
    if errOn then traceE(fmt("%s Secure channel is not in opened state.", self.logId)) end
    error(s.BadTcpMessageTypeInvalid)
  end

  if dbgOn then traceD(fmt("%s Processing message ID: %s", self.logId, msg.requestId)) end

  local i = msg.requestId
  -- Generating of error response only on encoding/decoding errors
  -- Processing of a valid request can cause only service fault response.
  -- In case of service fault return code will be Good, but response header will contain
  -- corresponding code of service processing error.
  if self.state == State.Hello then
    if i == Msg.FIND_SERVERS_REQUEST then
      self:processRequest(msg, MD.findServersRequest, ME.findServersResponse, self.services.findServers, "Browse")
    elseif i == Msg.GET_ENDPOINTS_REQUEST then
      self:processRequest(msg, MD.getEndpointsRequest, ME.getEndpointsResponse, self.services.getEndpoints, "GetEndpoints")
    else
      if errOn then traceE(fmt("%s Received message for closed secure channel.", self.logId)) end
      error(s.BadSecureChannelClosed)
    end
  elseif self.state == State.Open then
    if i == Msg.FIND_SERVERS_REQUEST then
      self:processRequest(msg, MD.findServersRequest,     ME.findServersResponse, self.services.findServers, "Browse")
    elseif i == Msg.GET_ENDPOINTS_REQUEST then
      self:processRequest(msg, MD.getEndpointsRequest,    ME.getEndpointsResponse, self.services.getEndpoints, "GetEndpoints")
    elseif i == Msg.CREATE_SESSION_REQUEST then
      self:processRequest(msg, MD.createSessionRequest,   ME.createSessionResponse, self.services.createSession, "CreateSession")
    elseif i == Msg.ACTIVATE_SESSION_REQUEST then
      self:processRequest(msg, MD.activateSessionRequest, ME.activateSessionResponse, self.services.activateSession, "ActivateSession")
    elseif i == Msg.CLOSE_SESSION_REQUEST then
      self:processRequest(msg, MD.closeSessionRequest,    ME.closeSessionResponse, self.services.closeSession, "CloseSession")
    elseif i == Msg.BROWSE_REQUEST then
      self:processRequest(msg, MD.browseRequest,          ME.browseResponse, self.services.browse, "Browse")
    elseif i == Msg.READ_REQUEST then
      self:processRequest(msg, MD.readRequest,            ME.readResponse, self.services.read, "Read")
    elseif i == Msg.WRITE_REQUEST then
      self:processRequest(msg, MD.writeRequest,           ME.writeResponse, self.services.write, "Write")
    elseif i == Msg.CREATE_SUBSCRIPTION_REQUEST then
      self:processRequest(msg, MD.createSubscriptionRequest, ME.createSubscriptionResponse, self.services.createSubscription, "CreateSubscription")
    elseif i == Msg.TRANSLATE_BROWSE_PATHS_TO_NODE_IdS_REQUEST then
      self:processRequest(msg, MD.translateBrowsePathsToNodeIdsRequest, ME.translateBrowsePathsToNodeIdsResponse, self.services.translateBrowsePaths, "TranslateBrowsePathsToNodeIds")
    elseif i == Msg.ADD_NODES_REQUEST then
      self:processRequest(msg, MD.addNodesRequest,        ME.addNodesResponse, self.services.addNodes, "AddNodes")
    else
      -- TODO NEED REMOVE EXTRA DATA OF NOT IMPLEMENTED REQUEST BODY
      if errOn then traceE(fmt("%s Not implemented message ID: ", self.logId, msg.requestId)) end
      local header = self.decoder:requestHeader()
      self:responseServiceFault(msg, header, s.BadNotImplemented)
    end
  else
    if errOn then traceE(fmt("%s Received message for closed secure channel.", self.logId)) end
    error(s.BadSecureChannelClosed)
  end
end


function S:processRequest(msg, decMethod, encMethod, processMethod, reqName)
  local dbgOn = self.trace.dbgOn

  -- Decode request
  local request = decMethod(self.decoder)

  local header = request.requestHeader
  if dbgOn then traceD(fmt("%s Processing %s request handle %d", self.logId, reqName, header.requestHandle)) end

  local suc
  local result
  -- check token
  suc, result = pcall(self.setToken, self, msg.secureHeader.tokenId)
  if suc then
    suc, result = pcall(processMethod, self.services, request)
  end

  -- Encode response
  if suc then
    if dbgOn then traceD(fmt("%s Encoding %s response", self.logId, reqName)) end
    local resp = self:fillResponseParams(msg, header, 0)
    encMethod(self.encoder, resp, result)
  else
    if dbgOn then traceD(fmt("%s Encoding %s service fault: %X", self.logId, reqName, result)) end
    local resp = self:fillResponseParams(msg, header, result)
    encMethod(self.encoder, resp, nil)
  end
end

function S:fillResponseParams(msg, requestHeader, statusCode)
  return {
    requestId = msg.sequenceHeader.requestId,
    channelTokenId = msg.secureHeader.tokenId,
    channelId = self.channelId,
    requestHandle = requestHeader.requestHandle,
    requestCreatedAt = socket.gettime(),
    serviceResult = statusCode == nil and s.Good or statusCode
  }
end

function S:responseAbort(err, message)
  if self.trace.E then trace.E(fmt("%s sending ABORT. Error 0x%x", self.logId, err)) end
  self.state = State.Closed
  self.encoder:abort(err, message)
end

function S:responseServiceFault(msg, header, faultCode)
  if self.trace.E then trace.E(fmt("%s Sending SERVICE_FAULT 0x%x", self.logId, faultCode)) end
  local resp = self:fillResponseParams(msg, header, faultCode)
  return self.encoder:serviceFaultResponse(resp)
end

function S:setToken(tokenId)
  local errOn = self.trace.errOn
  local time = socket.gettime()
  self:cleanupExpredTokens(time)

  local token = self.tokens[tokenId]
  if token == nil then
    if errOn then traceE(fmt("%s Unknown token %d", self.logId, tokenId)) end
    error(s.BadSecureChannelTokenUnknown)
  end

  if time > token.expiresAt then
    if errOn then traceE(fmt("%s Secure token %d expired.", self.logId, tokenId)) end
    error(s.BadSecurityChecksFailed)
  end

  self.encoder.chunks.secureHeader.tokenId = tokenId
  self.logId = fmt("binary | %s:%s", self.channelId, tokenId)
  return s.Good
end


function S:cleanupExpredTokens(time)
  local dbgOn = self.trace.dbgOn
  local infOn = self.trace.infOn

  if dbgOn then traceD(fmt("%s Cleaning up tokens", self.logId)) end

  for id,token in pairs(self.tokens) do
    if time > token.expiresAt then
      if infOn then traceI(fmt("%s expired token %s ", self.logId, id)) end
      self.tokens[id] = nil
    else
      if dbgOn then traceD(fmt("%s token %s: %d secs ", self.logId, id, token.expiresAt - time)) end
    end
  end

  if dbgOn then traceD(fmt("%s Tokens cleaned up", self.logId)) end
end

local function newConnection(config, services, out)
  assert(config ~= nil)
  assert(services ~= nil)
  assert(out ~= nil)
  assert(config.bufSize >= 8192)

  channelsNum = channelsNum + 1
  local c = {
    requestId = 0,
    channelId = channelsNum,
    tokens = {},
    securityPolicyUri = ua.Types.SecurityPolicy.None,
    services = services,
    out = out,
    decoder = MD.new(config.bufSize),
    bufSize = 0,
    state = State.New,
    config = config,
    trace = config.logging.binary
  }

  c.encoder = ME.new(config, c)

  setmetatable(c, S)

  c.encoder.chunks.channelId = channelsNum
  c.encoder.chunks.secureHeader.tokenId = 0
  c.logId = fmt("binary | %s:%s", channelsNum, 0)

  return c
end

return {
  new=newConnection,
}
