local ua = require("opcua.api")
local binary = require("opcua.binary.encode_types")
local HeaderType = binary.HeaderType
local s = ua.Status
local Q = require("opcua.binary.queue")
local MessageId = require "opcua.binary.message_id"

local BadEncodingError = s.BadEncodingError
local BadNodeAttributesInvalid = s.BadNodeAttributesInvalid

local tins = table.insert

local ME = {}
ME.__index = ME

function ME:messageTypeID(id)
  return self.mEnc:nodeId(id)
end

local function makeEmptyAdditionalHeader()
  local hdr = {}
  hdr.binaryBody = 0
  hdr.xmlBody = 0
  hdr.typeId = {id=0}
  return hdr
end


local function createRequestHeader(requestParams)
  return {
    authenticationToken = requestParams.sessionAuthToken,
    timestamp = requestParams.requestCreatedAt,
    requestHandle = requestParams.requestHandle,
    returnDiagnostics = 0,
    auditEntryId = nil,
    timeoutHint = requestParams.requestTimeout,
    additionalHeader = makeEmptyAdditionalHeader(),
  }
end

local function createResponseHeader(responseParams)
  return {
    timestamp = responseParams.requestCreatedAt,
    requestHandle = responseParams.requestHandle,
    serviceResult = responseParams.serviceResult,
    serviceDiagnostics = {},
    stringTable = {},
    additionalHeader = makeEmptyAdditionalHeader()
  }
end


function ME:hello(hello)
  self.chunks:begin(HeaderType.Hello)
  self.mEnc:hello(hello)
  self.chunks:finish()
end

function ME:acknowledge(ack)
  self.chunks:begin(HeaderType.Acknowledge)
  self.mEnc:acknowledge(ack)
  self.chunks:finish()
end

------------------------------------------------------
-------           ABORT                        -------
------------------------------------------------------

function ME:abort(errCode, reason)
  self.chunks:begin(HeaderType.Error)

  local abort = {
    error = errCode,
    reason = reason
  }
  self.mEnc:abort(abort)
  self.chunks:finish()
end

function ME:openSecureChannelRequest(requestParams, channelParams)
  self.chunks.channelId = 0
  self.chunks.secureHeader.tokenId = 0

  self.chunks:begin(HeaderType.Open, requestParams.requestId)
  self:messageTypeID(MessageId.OPEN_SECURE_CHANNEL_REQUEST)

  local request = {
    requestHeader = createRequestHeader(requestParams),
    clientProtocolVersion = 0,
    requestType = channelParams.requestType,
    securityMode = channelParams.securityMode,
    clientNonce = channelParams.clientNonce,
    requestedLifetime = channelParams.requestedLifetime,
  }

  self.mEnc:openSecureChannelRequest(request)
  self.chunks:finish()
end

function ME:closeSecureChannelRequest(requestParams)
  self.chunks:begin(HeaderType.Close, requestParams.requestId)
  self:messageTypeID(MessageId.CLOSE_SECURE_CHANNEL_REQUEST)

  local request = {
    requestHeader = createRequestHeader(requestParams),
  }
  self.mEnc:closeSecureChannelRequest(request)
  self.chunks:finish()
end

function ME:openSecureChannelResponse(responseParams, channelParams)
  assert(responseParams.serviceResult ~= nil)

  self.chunks:begin(HeaderType.Open, responseParams.requestId)
  self:messageTypeID(MessageId.OPEN_SECURE_CHANNEL_RESPONSE)

  local response = {
    responseHeader = createResponseHeader(responseParams),

    securityToken = {
      channelId = channelParams.channelId,
      tokenId =   channelParams.channelTokenId,
      createdAt = channelParams.channelCreatedAt,
      revisedLifetime = channelParams.revisedLifetime,
    },

    serverNonce = channelParams.serverNonce,
    serverProtocolVersion = 0,
  }
  self.mEnc:openSecureChannelResponse(response)
  self.chunks:finish()
end

function ME:beginMessage(msgID, requestId)
  self.chunks:begin(HeaderType.Message, requestId)
  self:messageTypeID(msgID)
end

function ME:findServersRequest(requestParams, findServersParams)
  self:beginMessage(MessageId.FIND_SERVERS_REQUEST, requestParams.requestId)
  local request = {
    requestHeader = createRequestHeader(requestParams),
    endpointUrl = findServersParams.endpointUrl,
    localeIds = {},
    serverUris = {}
  }

  self.mEnc:findServersRequest(request)
  self.chunks:finish()
end

-- Servers must be an array
function ME:findServersResponse(responseParams, servers)
  self:beginMessage(MessageId.FIND_SERVERS_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    servers = servers
  }

  self.mEnc:findServersResponse(response)
  self.chunks:finish()
end

function ME:getEndpointsRequest(requestParams, getEndpointsParams)
  self:beginMessage(MessageId.GET_ENDPOINTS_REQUEST, requestParams.requestId)
  local request = {
    requestHeader = createRequestHeader(requestParams),
    endpointUrl = getEndpointsParams.endpointUrl,
    localeIds = {},
    profileUris = {}
  }

  self.mEnc:getEndpointsRequest(request)
  self.chunks:finish()
end

function ME:getEndpointsResponse(responseParams, endpoints)
  self:beginMessage(MessageId.GET_ENDPOINTS_RESPONSE, responseParams.requestId)
  local response = {
    responseHeader = createResponseHeader(responseParams),
    endpoints = endpoints
  }
  self.mEnc:getEndpointsResponse(response)
  self.chunks:finish()
end

function ME:createSessionRequest(requestParams, sessionParams)
  self:beginMessage(MessageId.CREATE_SESSION_REQUEST, requestParams.requestId)

  local request = {
    requestHeader = createRequestHeader(requestParams),

    clientDescription = {
      applicationUri = sessionParams.applicationUri,
      productUri = sessionParams.productUri,
      applicationName = {
        text = sessionParams.applicationName
      },
      applicationType = sessionParams.applicationType,
      gatewayServerUri = nil,
      discoveryProfileUri = nil,
      discoveryUrls = {},
    },
    serverUri = sessionParams.serverUri,
    endpointUrl = sessionParams.endpointUrl,
    sessionName = sessionParams.sessionName,
    clientNonce = sessionParams.clientNonce,
    clientCertificate = sessionParams.clientCertificate,

    requestedSessionTimeout = sessionParams.sessionTimeout,
    maxResponseMessageSize = 0
  }

  self.mEnc:createSessionRequest(request)
  self.chunks:finish()
end

function ME:createSessionResponse(responseParams, sessionParams)
  self:beginMessage(MessageId.CREATE_SESSION_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    sessionId = sessionParams.id,
    authenticationToken = sessionParams.authToken,
    revisedSessionTimeout = sessionParams.revisedSessionTimeout,
    serverNonce = sessionParams.serverNonce,
    serverCertificate = sessionParams.serverCertificate,
    serverSoftwareCertificates = nil,
    serverSignature = {
      algorithm = nil,
      signature = nil
    },
    maxRequestMessageSize = sessionParams.maxRequestMessageSize
  }

  response.serverEndpoints = {}
  for _,eParam in ipairs(sessionParams.serverEndpoints) do
    local endpoint = {
      endpointUrl = eParam.endpointUrl,
      server = {
        applicationType = eParam.applicationType,
        applicationUri = eParam.applicationUri,
        productUri = eParam.productUri,
        applicationName = eParam.applicationName,
        gatewayServerUri = eParam.gatewayServerUri,
        discoveryProfileUri = eParam.discoveryProfileUri,
        discoveryUrls = eParam.discoveryUrls,
      },
      serverCertificate = sessionParams.serverCertificate,
      securityMode = eParam.securityMode,
      securityPolicyUri = eParam.securityPolicyUri,
      userIdentityTokens = eParam.userIdentityTokens,
      transportProfileUri = eParam.transportProfileUri,
      securityLevel = eParam.securityLevel
    }
    tins(response.serverEndpoints, endpoint)
  end

  self.mEnc:createSessionResponse(response)
  self.chunks:finish()
end

function ME:activateSessionRequest(requestParams, sessionParams)
  self:beginMessage(MessageId.ACTIVATE_SESSION_REQUEST, requestParams.requestId)

  local request = {}
  request.requestHeader = createRequestHeader(requestParams)
  request.clientSignature = {
    algorithm = sessionParams.clientSignature.algorithm,
    signature = sessionParams.clientSignature.signature
  }
  request.clientSoftwareCertificates = sessionParams.clientSoftwareCertificates
  request.localeIds = sessionParams.locales
  request.userIdentityToken = {
    typeId = ua.NodeId.toString(321)
  }

  do
    local q = Q.new(#sessionParams.userIdentityToken + 4) -- length od data + sizeof dword
    local enc = binary.Encoder.new(q)
    enc:byteString(sessionParams.userIdentityToken)
    request.userIdentityToken.body = q
  end

  request.userTokenSignature = {
    algorithm = nil,
    signature = nil
  }

  self.mEnc:activateSessionRequest(request)
  self.chunks:finish()
end

function ME:activateSessionResponse(responseParams, sessionParams)
  self:beginMessage(MessageId.ACTIVATE_SESSION_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    serverNonce = nil,
    results = sessionParams.activationResultCodes,
    diagnosticInfos = {}
  }

  self.mEnc:activateSessionResponse(response)
  self.chunks:finish()
end

function ME:closeSessionRequest(requestParams, sessionParams)
  self:beginMessage(MessageId.CLOSE_SESSION_REQUEST, requestParams.requestId)
  local request = {
    requestHeader = createRequestHeader(requestParams),
    deleteSubscriptions = sessionParams.deleteSubscriptions
  }

  self.mEnc:closeSessionRequest(request)
  self.chunks:finish()
end

function ME:closeSessionResponse(responseParams)
  self:beginMessage(MessageId.CLOSE_SESSION_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams)
  }

  self.mEnc:closeSessionResponse(response)
  self.chunks:finish()
end

function ME:browseRequest(requestParams, browseParams)
  self:beginMessage(MessageId.BROWSE_REQUEST, requestParams.requestId)

  local request = {}
  request.requestHeader = createRequestHeader(requestParams)

  if browseParams.requestedMaxReferencesPerNode ~= nil then
    request.requestedMaxReferencesPerNode = browseParams.requestedMaxReferencesPerNode
  else
    request.requestedMaxReferencesPerNode = 0
  end

  if browseParams.view ~= nil then
    request.view = {
      viewId = browseParams.view,
      timestamp = browseParams.view.timestamp,
      viewVersion = browseParams.view.version
    }
  else
    request.view = {
      viewId = ua.NodeId.Null,
      timestamp = 0,
      viewVersion = 0
    }
  end

  request.nodesToBrowse = {}
  for _,n in ipairs(browseParams.nodesToBrowse) do
    local browse = {
      nodeId = n.nodeId,
      browseDirection = n.browseDirection,
      referenceTypeId = n.referenceTypeId,
      nodeClassMask = n.nodeClass,
      resultMask = n.resultMask,
      includeSubtypes = n.includeSubtypes
    }
    tins(request.nodesToBrowse, browse)
  end

  self.mEnc:browseRequest(request)
  self.chunks:finish()
end

function ME:browseResponse(responseParams, browseResults)
  self:beginMessage(MessageId.BROWSE_RESPONSE, responseParams.requestId)

  local response = {}
  response.responseHeader = createResponseHeader(responseParams)
  response.diagnosticInfos = {}
  response.results = {}
  for _,tmpResult in ipairs(browseResults) do
    local result = {}
    result.statusCode = tmpResult.statusCode
    result.continuationPoint = tmpResult.continuationPoint

    result.references = {}
    for _,tmpRef in ipairs(tmpResult.references) do
      local ref = {}
      ref.referenceTypeId = tmpRef.referenceTypeId
      ref.isForward = tmpRef.isForward
      ref.nodeId = tmpRef.nodeId
      ref.nodeClass = tmpRef.nodeClass
      ref.typeDefinition = tmpRef.typeDefinition
      ref.browseName = tmpRef.browseName
      ref.displayName = tmpRef.displayName
      tins(result.references, ref)
    end

    tins(response.results, result)
  end

  self.mEnc:browseResponse(response)
  self.chunks:finish()
end

function ME:readRequest(requestParams, nodes)
  self:beginMessage(MessageId.READ_REQUEST, requestParams.requestId)

  local request = {}
  request.requestHeader = createRequestHeader(requestParams)
  request.maxAge = nodes.maxAge or 0
  request.timestampsToReturn = nodes.timestampsToReturn or 0

  request.nodesToRead = {}
  for _,n in ipairs(nodes) do
    local id = {}
    id.nodeId = n.nodeId
    id.attributeId = n.attributeId
    id.indexRange = id.indexRange
    id.dataEncoding = {
      ns = 0,
      name = nil
    }

    tins(request.nodesToRead, id)
  end

  self.mEnc:readRequest(request)
  self.chunks:finish()
end

------------------------------------------------------
-------            READ_RESPONSE               -------
------------------------------------------------------

function ME:readResponse(responseParams, readResults)
  self:beginMessage(MessageId.READ_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    results = readResults,
    diagnosticInfos = {}
  }

  self.mEnc:readResponse(response)
  self.chunks:finish()
end

------------------------------------------------------
-------   CREATE_SUBSCRIPTION_REQUEST          -------
------------------------------------------------------

function ME:createSubscriptionRequest(requestParams, subscriptionParams)
  self:beginMessage(MessageId.CREATE_SUBSCRIPTION_REQUEST, requestParams.requestId)

  local request = {
    requestHeader = createRequestHeader(requestParams),
    requestedPublishingInterval = subscriptionParams.requestedPublishingInterval,
    requestedLifetimeCount = subscriptionParams.requestedLifetimeCount,
    requestedMaxKeepAliveCount = subscriptionParams.requestedMaxKeepAliveCount,
    maxNotificationsPerPublish = subscriptionParams.maxNotificationsPerPublish,
    publishingEnabled = subscriptionParams.publishingEnabled,
    priority = subscriptionParams.priority
  }

  self.mEnc:createSubscriptionRequest(request)
  self.chunks:finish()
end

function ME:createSubscriptionResponse(responseParams, subscription)
  self:beginMessage(MessageId.CREATE_SUBSCRIPTION_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    subscriptionId = subscription.subscriptionId,
    revisedPublishingInterval = subscription.revisedPublishingInterval,
    revisedLifetimeCount = subscription.revisedLifetimeCount,
    revisedMaxKeepAliveCount = subscription.revisedMaxKeepAliveCount
  }

  self.mEnc:createSubscriptionResponse(response)
  self.chunks:finish()
end

function ME:translateBrowsePathsToNodeIdsRequest(requestParams, browsePaths)
  self:beginMessage(MessageId.TRANSLATE_BROWSE_PATHS_TO_NODE_IdS_REQUEST, requestParams.requestId)

  local request = {
    requestHeader = createRequestHeader(requestParams),
    browsePaths = browsePaths
  }

  self.mEnc:translateBrowsePathsToNodeIdsRequest(request)
  self.chunks:finish()
end

function ME:translateBrowsePathsToNodeIdsResponse(responseParams, results)
  self:beginMessage(MessageId.TRANSLATE_BROWSE_PATHS_TO_NODE_IdS_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    results = results,
    diagnosticInfos = {}
  }

  self.mEnc:translateBrowsePathsToNodeIdsResponse(response)
  self.chunks:finish()
end

function ME:writeRequest(requestParams, nodesToWrite)
  self:beginMessage(MessageId.WRITE_REQUEST, requestParams.requestId)

  local request = {
    requestHeader = createRequestHeader(requestParams),
    nodesToWrite = nodesToWrite
  }

  self.mEnc:writeRequest(request)
  self.chunks:finish()
end

function ME:writeResponse(responseParams, results)
  self:beginMessage(MessageId.WRITE_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    results = results,
    diagnosticInfos = {}
  }

  self.mEnc:writeResponse(response)
  self.chunks:finish()
end

local maskNames = {
  accessLevel = "AccessLevel",
  arrayDimensions = "ArrayDimensions",
  browseName = "BrowseName",
  containsNoLoops = "ContainsNoLoops",
  dataType = "DataType",
  description = "Description",
  displayName = "DisplayName",
  eventNotifier = "EventNotifier",
  executable = "Executable",
  historizing = "Historizing",
  inverseName = "InverseName",
  isAbstract = "IsAbstract",
  minimumSamplingInterval = "MinimumSamplingInterval",
  nodeClass = "NodeClass",
  nodeId = "NodeId",
  symmetric = "Symmetric",
  userAccessLevel = "UserAccessLevel",
  userExecutable = "UserExecutable",
  userWriteMask = "UserWriteMask",
  valueRank = "ValueRank",
  writeMask = "WriteMask",
  value = "Value",
  all = "All",
  baseNode = "BaseNode",
  object = "Object",
  objectTypeOrDataType = "ObjectTypeOrDataType",
  variable = "Variable",
  variableType = "VariableType",
  method = "Method",
  referenceType = "ReferenceType",
  view = "View",
}

local function getAttributesMask(attrs)
  local mask = 0
  for k,_ in pairs(attrs) do
    local maskName = maskNames[k]
    if ua.Types.NodeAttributesMask[maskName] == nil then
      error(BadNodeAttributesInvalid)
    end
    mask = mask | ua.Types.NodeAttributesMask[maskName]
  end
  return mask
end

function ME:addNodesRequest(requestParams, nodes)
  self:beginMessage(MessageId.ADD_NODES_REQUEST, requestParams.requestId)

  local request = {}
  request.requestHeader = createRequestHeader(requestParams)
  request.nodesToAdd = {}
  for _,node in ipairs(nodes.nodesToAdd) do
    local ext = {
      body = Q.new(2048)
    }

    local attrs = node.nodeAttributes
    attrs.specifiedAttributes = getAttributesMask(attrs)

    local encodeFunc
    local bEnc = binary.Encoder.new(ext.body)
    if node.nodeClass == ua.Types.NodeClass.Variable then
      -- ua.NodeIds.VariableAttributes_Encoding_DefaultBinary
      ext.typeId = "i=357"
      encodeFunc = bEnc.variableAttributes
    elseif node.nodeClass == ua.Types.NodeClass.Object then
      --ua.NodeIds.ObjectAttributes_Encoding_DefaultBinary
      ext.typeId = "i=354"
      encodeFunc = bEnc.objectAttributes
    else
      error(BadEncodingError)
    end

    encodeFunc(bEnc, attrs);

    local reqNode = {
      parentNodeId = node.parentNodeId,
      referenceTypeId = node.referenceTypeId,
      requestedNewNodeId = node.requestedNewNodeId,
      browseName = node.browseName,
      nodeClass = node.nodeClass,
      nodeAttributes = ext,
      typeDefinition = node.typeDefinition,
    }
    tins(request.nodesToAdd, reqNode)
  end

  self.mEnc:addNodesRequest(request)
  self.chunks:finish()
end

function ME:addNodesResponse(responseParams, results)
  self:beginMessage(MessageId.ADD_NODES_RESPONSE, responseParams.requestId)

  local response = {
    responseHeader = createResponseHeader(responseParams),
    results = results,
    diagnosticInfos = {}
  }

  self.mEnc:addNodesResponse(response)
  self.chunks:finish()
end

function ME:serviceFaultResponse(responseParams)
  self:beginMessage(MessageId.SERVICE_FAULT, responseParams.requestId)

  -- Response Body
  local responseHeader = createResponseHeader(responseParams)
  self.mEnc:responseHeader(responseHeader)
  self.chunks:finish()
end

------------------------------------------------------------

function ME.new(config, sock)
  assert(config ~= nil)
  assert(sock ~= nil)

  local ChunkEncoder = require("opcua.binary.chunks_encode")

  local chunks = ChunkEncoder.new(config, sock)
  local mEnc = binary.Encoder.new(chunks)

  local stream = {
    -- Queue where will be put result message/chunk
    chunks = chunks,
    -- encoder will put data to
    mEnc = mEnc,
  }

  setmetatable(stream, ME)

  return stream
end

return ME
