local s = require("opcua.status_codes")
local Q = require("opcua.binary.queue")
local binary = require("opcua.binary.encode_types")
local tins = table.insert

local BadDecodingError = s.BadDecodingError

local MD = {}
MD.__index = MD

function MD:hello()
  return self.decoder:hello()
end

function MD:acknowledge()
  return self.decoder:acknowledge()
end

function MD:openSecureChannelRequest()
  local msg = self:secureMessageHeader()
  msg.secureHeader = self.decoder:asymmetricSecurityHeader()
  msg.sequenceHeader = self:sequenceHeader()
  msg.requestId = self:requestId()
  msg.openSecureChannelRequest = self.decoder:openSecureChannelRequest()
  return msg
end

function MD:findServersRequest()
  return self.decoder:findServersRequest()
end

function MD:getEndpointsRequest()
  return self.decoder:getEndpointsRequest()
end

function MD:createSessionRequest()
  return self.decoder:createSessionRequest()
end

function MD:activateSessionRequest()
  return self.decoder:activateSessionRequest()
end

function MD:closeSessionRequest()
  return self.decoder:closeSessionRequest()
end

function MD:browseRequest()
  return self.decoder:browseRequest()
end

function MD:readRequest()
  return self.decoder:readRequest()
end

function MD:createSubscriptionRequest()
  return self.decoder:createSubscriptionRequest()
end

function MD:translateBrowsePathsToNodeIdsRequest()
  return self.decoder:translateBrowsePathsToNodeIdsRequest()
end

function MD:writeRequest()
  return self.decoder:writeRequest()
end

function MD:addNodesRequest()
  local request = self.decoder:addNodesRequest()
  local addNodesRequest = {
    requestHeader = request.requestHeader,
    nodesToAdd = {}
  }

  for _,nodeToAdd in ipairs(request.nodesToAdd) do
    local q = Q.new(#nodeToAdd.nodeAttributes.body)
    local dec = binary.Decoder.new(q)
    q:pushBack(nodeToAdd.nodeAttributes.body)
    local node = {
      parentNodeId = nodeToAdd.parentNodeId,
      referenceTypeId = nodeToAdd.referenceTypeId,
      requestedNewNodeId = nodeToAdd.requestedNewNodeId,
      browseName = nodeToAdd.browseName,
      nodeClass = nodeToAdd.nodeClass,
      typeDefinition = nodeToAdd.typeDefinition,
    }

    -- nodeIds.VariableAttributes_Encoding_DefaultBinary
    if nodeToAdd.nodeAttributes.typeId == "i=357" then
      node.nodeAttributes = dec:variableAttributes()
    --nodeIds.ObjectAttributes_Encoding_DefaultBinary
    elseif nodeToAdd.nodeAttributes.typeId == "i=354" then
      node.nodeAttributes = dec:objectAttributes()
    else
      error(BadDecodingError)
    end
    tins(addNodesRequest.nodesToAdd, node)
  end

  return addNodesRequest
end

function MD:requestHeader()
  return self.decoder:requestHeader()
end

function MD:requestId()
  return self.decoder:nodeId()
end

function MD:sequenceHeader()
  return self.decoder:sequenceHeader()
end

function MD:symmetricSecurityHeader()
  return self.decoder:symmetricSecurityHeader()
end

function MD:messageHeader()
  return self.decoder:messageHeader()
end

function MD:secureMessageHeader()
  local channelId = self.decoder:uint32()
  return {channelId=channelId}
end

function MD:ensureData(size)
  if self.sock == nil then
    return
  end

  if #self.dataQ >= size then
    return
  end

  local data = self.sock:receive(size)
  self.dataQ:pushBack(data)
end

function MD.new(size)
  local q = Q.new(size)
  local dec = binary.Decoder.new(q)

  local result = {
    dataQ = q,
    decoder = dec,
  }

  setmetatable(result, MD)

  return result
end

return MD
