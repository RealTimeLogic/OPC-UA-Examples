local ua = require("opcua.api")
local Q = require("opcua.binary.queue")
local Binary = require("opcua.binary.encode_types")
local s = require("opcua.status_codes")
local ChunkType = Binary.ChunkType
local HeaderType = Binary.HeaderType

local fmt = string.format
local traceD = ua.trace.dbg

local ch ={}
ch.__index = ch

local HeaderSize = 8
local SecureHeaderSize = 12

local BadSecurityChecksFailed = s.BadSecurityChecksFailed
local BadInternalError = s.BadInternalError
local BadSecureChannelIdInvalid = s.BadSecureChannelIdInvalid
local BadSecureChannelTokenUnknown = s.BadSecureChannelTokenUnknown

function ch:begin(messageType, requestId)
  self.requestId = requestId
  self.messageType = messageType

  if self.messageType == HeaderType.Message or self.messageType == HeaderType.Close then
    if self.requestId == nil or self.requestId == 0 or self.securityPolicyUri == nil then
      error(BadSecurityChecksFailed)
    end
    if self.channelId == 0 then error(BadSecureChannelIdInvalid) end
    if self.secureHeader.tokenId == 0 then error(BadSecureChannelTokenUnknown) end
    self.headerSize = SecureHeaderSize + 12
  elseif self.messageType == HeaderType.Open then
    if self.requestId == nil or self.requestId == 0 or self.securityPolicyUri == nil then
      error(BadSecurityChecksFailed)
    end
    local sz = SecureHeaderSize + 20 + #self.securityPolicyUri
    if self.certificate ~= nil then
      sz = sz + #self.certificate
    end
    if self.certificateThumbprint ~= nil then
      sz = sz + #self.certificateThumbprint
    end
    self.headerSize = sz
  else
    self.headerSize = HeaderSize
  end

  self.data:clear(self.headerSize + 1)
end

-- Queue interface through which fills up message body
function ch:pushBack(data)
  if self.data:tailCapacity() <= 0 then
    self:send_chunk(ChunkType.Intermediate)
  end

  if type(data) == 'number' then
    self.data:pushBack(data)
  else
    local pos = 1
    local dsize = #data
    while pos <= dsize do
      if pos ~= 1 then
        self:send_chunk(ChunkType.Intermediate)
      end

      local tailCap = self.data:tailCapacity()
      local leftSize = dsize - (pos - 1)
      if leftSize > tailCap then
        leftSize = tailCap
      end

      for i = 0,(leftSize-1) do
        self.data:pushBack(data[pos+i])
      end

      pos = pos + leftSize
    end
  end
end

function ch:finish()
  self:send_chunk(ChunkType.Final)
end

function ch:abort()
  self.data:clear()
  self:send(ChunkType.Abort)
end

function ch:send_chunk(chunkType)
  if #self.data == 0 then
    error(BadInternalError)
  end

  if chunkType == ChunkType.Intermediate and self.messageType ~= HeaderType.Message then
    if self.trace.E then ua.trace.E(fmt("binary | %d Internal error: Message type '%s' can't be chunked.",self.channelId, self.messageType)) end
    self.data:clear()
    error(BadInternalError)
  end

  local dbgOn = self.config.logging.socket.dbgOn
  local chunkSize = #self.data + self.headerSize

  local headerQ = Q.new(self.headerSize)
  local header = Binary.Encoder.new(headerQ)
  if self.messageType == HeaderType.Message or self.messageType == HeaderType.Close then
    assert(self.channelId ~= 0)
    assert(self.secureHeader.tokenId ~= 0)
    assert(self.requestId ~= 0 and self.requestId ~= nil)
    header:symmetricSecurityHeader(self.secureHeader)
    self:sequenceHeader(header)
    self.data:pushFront(headerQ.Buf)
  elseif self.messageType == HeaderType.Open then
    assert(self.requestId ~= 0 and self.requestId ~= nil)
    assert(self.securityPolicyUri ~= nil)
    header:asymmetricSecurityHeader(self.securityPolicyUri, self.certificate, self.certificateThumbprint)
    self:sequenceHeader(header)
    self.data:pushFront(headerQ.Buf)
  end

  headerQ:clear()
  if self.messageType == HeaderType.Message or self.messageType == HeaderType.Open or self.messageType == HeaderType.Close then
    header:secureMessageHeader(self.messageType, chunkType, chunkSize, self.channelId)
  else
    header:messageHeader(self.messageType, chunkType, chunkSize)
  end

  self.data:pushFront(headerQ.Buf)
  self.sock:send(self.data.Buf)
  self.data:clear(self.headerSize + 1)
  if dbgOn then traceD(fmt("binary | %d Data sent sucessfully", self.channelId)) end
end

function ch:sequenceHeader(enc)
  self.sequenceNumber = self.sequenceNumber + 1
  local sequenceHeader = {
    sequenceNumber = self.sequenceNumber,
    requestId = self.requestId
  }
  enc:sequenceHeader(sequenceHeader)
end

local function new(config, sock)
  assert(config ~= nil)
  assert(sock ~= nil)

  local dataQ = Q.new(config.bufSize)

  local res = {
    config = config,
    trace = config.logging.binary,

    channelId = 0,
    secureHeader = {
      tokenId = 0
    },

    requestId = 0,
    sequenceNumber = 0,

    securityPolicyUri = config.securityPolicyUri,
    certificate = config.certificate,
    certificateThumbprint = config.certificateThumbprint,

    headerSize = 0,

    -- buffer for Chunk.
    data = dataQ,
    -- Binary types encoder
    dataEnc = Binary.Encoder.new(dataQ),

    -- Socket where to flush chunks
    sock = sock
  }

  setmetatable(res, ch)

  return res
end

return {new=new}
