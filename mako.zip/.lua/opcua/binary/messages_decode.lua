local binary = require("opcua.binary.encode_types")
local HeaderType = require("opcua.binary.encode_types").HeaderType
local ChunkType = require("opcua.binary.encode_types").ChunkType

local s = require("opcua.status_codes")
local Q = require("opcua.binary.queue")

local tins = table.insert

local BadDecodingError = s.BadDecodingError
local BadCommunicationError = s.BadCommunicationError

local MD = {}
MD.__index = MD

local HeaderSize = 8

function MD:hello()
  self:recvMessage(HeaderType.Hello, ChunkType.Final)
  return self.decoder:hello()
end

function MD:acknowledge()
  self:recvMessage(HeaderType.Acknowledge, ChunkType.Final)
  return self.decoder:acknowledge()
end

function MD:abort()
  self:recvMessage(HeaderType.Error, ChunkType.Final)
  return self.decoder:abort()
end


function MD:openSecureChannelRequest()
  return {
    messageHeader = self:recvSecureMessage(HeaderType.Open, ChunkType.Final),
    secureHeader = self.decoder:asymmetricSecurityHeader(),
    sequenceHeader = self.decoder:sequenceHeader(),
    requestId = self.decoder:nodeId(),
    openSecureChannelRequest = self.decoder:openSecureChannelRequest()
  }
end

function MD:openSecureChannelResponse()
  return {
    messageHeader = self:recvSecureMessage(HeaderType.Open, ChunkType.Final),
    secureHeader = self.decoder:asymmetricSecurityHeader(),
    sequenceHeader = self.decoder:sequenceHeader(),
    requestId = self.decoder:expandedNodeId(),
    openSecureChannelResponse = self.decoder:openSecureChannelResponse()
  }
end


function MD:findServersRequest()
  local msg = self:symmetricSecurityHeader()
  msg.findServersRequest = self.decoder:findServersRequest()
  return msg
end

function MD:findServersResponse()
  local msg = self:symmetricSecurityHeader()
  msg.findServersResponse = self.decoder:findServersResponse()
  return msg
end


function MD:getEndpointsRequest()
  local msg = self:symmetricSecurityHeader()
  msg.getEndpointsRequest = self.decoder:getEndpointsRequest()
  return msg
end

function MD:getEndpointsResponse()
  local msg = self:symmetricSecurityHeader()
  msg.getEndpointsResponse = self.decoder:getEndpointsResponse()
  return msg
end

function MD:createSessionRequest()
  local msg = self:symmetricSecurityHeader()
  msg.createSessionRequest = self.decoder:createSessionRequest()
  return msg
end

function MD:createSessionResponse()
  local msg = self:symmetricSecurityHeader()
  msg.createSessionResponse = self.decoder:createSessionResponse()
  return msg
end

function MD:activateSessionRequest()
  local msg = self:symmetricSecurityHeader()
  msg.activateSessionRequest = self.decoder:activateSessionRequest()
  return msg
end

function MD:activateSessionResponse()
  local msg = self:symmetricSecurityHeader()
  msg.activateSessionResponse = self.decoder:activateSessionResponse()
  return msg
end

function MD:closeSessionRequest()
  local msg = self:symmetricSecurityHeader()
  msg.closeSessionRequest = self.decoder:closeSessionRequest()
  return msg
end

function MD:closeSessionResponse()
  local msg = self:symmetricSecurityHeader()
  msg.closeSessionResponse = self.decoder:closeSessionResponse()
  return msg
end

function MD:browseRequest()
  local msg = self:symmetricSecurityHeader()
  msg.browseRequest = self.decoder:browseRequest()
  return msg
end

function MD:browseResponse()
  local msg = self:symmetricSecurityHeader()
  msg.browseResponse = self.decoder:browseResponse()
  return msg
end

function MD:readRequest()
  local msg = self:symmetricSecurityHeader()
  msg.readRequest = self.decoder:readRequest()
  return msg
end

function MD:readResponse()
  local msg = self:symmetricSecurityHeader()
  msg.readResponse = self.decoder:readResponse()
  return msg
end

function MD:createSubscriptionRequest()
  local msg = self:symmetricSecurityHeader()
  msg.createSubscriptionRequest = self.decoder:createSubscriptionRequest()
  return msg
end

function MD:createSubscriptionResponse()
  local msg = self:symmetricSecurityHeader()
  msg.createSubscriptionResponse = self.decoder:createSubscriptionResponse()
  return msg
end

function MD:translateBrowsePathsToNodeIdsRequest()
  local msg = self:symmetricSecurityHeader()
  msg.translateBrowsePathsToNodeIdsRequest = self.decoder:translateBrowsePathsToNodeIdsRequest()
  return msg
end

function MD:translateBrowsePathsToNodeIdsResponse()
  local msg = self:symmetricSecurityHeader()
  msg.translateBrowsePathsToNodeIdsResponse = self.decoder:translateBrowsePathsToNodeIdsResponse()
  return msg
end

function MD:writeRequest()
  local msg = self:symmetricSecurityHeader()
  msg.writeRequest = self.decoder:writeRequest()
  return msg
end

function MD:writeResponse()
  local msg = self:symmetricSecurityHeader()
  msg.writeResponse = self.decoder:writeResponse()
  return msg
end

function MD:addNodesRequest()
  local msg = self:symmetricSecurityHeader()
  local request = self.decoder:addNodesRequest()
  msg.addNodesRequest = {
    requestHeader = request.requestHeader,
    nodesToAdd = {}
  }

  for _,nodeToAdd in ipairs(request.nodesToAdd) do
    local q = Q.new(#nodeToAdd.nodeAttributes.body)
    local dec = binary.Decoder.new(q)
    q:pushBack(nodeToAdd.nodeAttributes.body)
    local node = {
      parentNodeId = nodeToAdd.parentNodeId,
      referenceTypeId = nodeToAdd.referenceTypeId,
      requestedNewNodeId = nodeToAdd.requestedNewNodeId,
      browseName = nodeToAdd.browseName,
      nodeClass = nodeToAdd.nodeClass,
      typeDefinition = nodeToAdd.typeDefinition,
    }

    -- nodeIds.VariableAttributes_Encoding_DefaultBinary
    if nodeToAdd.nodeAttributes.typeId == "i=357" then
      node.nodeAttributes = dec:variableAttributes()
    -- nodeIds.ObjectAttributes_Encoding_DefaultBinary
    elseif nodeToAdd.nodeAttributes.typeId == "i=354" then
      node.nodeAttributes = dec:objectAttributes()
    else
      error(BadDecodingError)
    end

    tins(msg.addNodesRequest.nodesToAdd, node)
  end

  return msg
end

function MD:addNodesResponse()
  local msg = self:symmetricSecurityHeader()
  msg.addNodesResponse = self.decoder:addNodesResponse()
  return msg
end

function MD:serviceFaultResponse()
  local msg = self:symmetricSecurityHeader()
  msg.serviceFaultResponse = {
    responseHeader = self.decoder:responseHeader()
  }
  return msg
end


------------------------------------------------------
-------    SYMMETRIC_SEURITY_HEADERS           -------
------------------------------------------------------
-- After opening secue channel all requests have common headers structure:
--  * Secure Message Header: Message type + Chunk type
--  * Symmetric Security Header: Channel token.
--  * Sequense Header: Request Num and chunk Num.
--  * Request ID: current Message ID.
--Body:
--  * Different for every request:


function MD:symmetricSecurityHeader()
  return {
    messageHeader = self:recvSecureMessage(HeaderType.Message, ChunkType.Final),
    secureHeader = self.decoder:symmetricSecurityHeader(),
    sequenceHeader = self.decoder:sequenceHeader(),
    requestId = self.decoder:expandedNodeId()
  }
end

function MD:recvMessage(msgType, chunkType)
  self:ensureData(HeaderSize)
  local header = self.decoder:messageHeader()
  if header.type ~= msgType then
    error(BadDecodingError)
  end
  if header.chunk ~= chunkType then
    error(BadDecodingError)
  end

  self:ensureData(header.messageSize - HeaderSize)
end

function MD:recvSecureMessage(msgType, chunkType, channelId)
  self:ensureData(HeaderSize)

  local header = self.decoder:messageHeader()

  self:ensureData(header.messageSize - HeaderSize)
  if header.type ~= msgType then
    if header.type == HeaderType.Error then
      local err = self.decoder:abort()
      error(err.error)
    end
    return
  end

  if header.chunk ~= chunkType then
    error(BadDecodingError)
  end

  header.channelId = self.decoder:uint32()
  if channelId ~= nil and header.channelId ~= channelId then
    error(BadDecodingError)
  end

  return header
end


function MD:ensureData(size)
  if self.sock == nil then return end
  if #self.dataQ >= size then return end

  local data,err,part = self.sock:receive(size)
  if err == "closed" then
    error(BadCommunicationError)
  end
  if part ~= nil and err == "timeout" then
    self.dataQ:pushBack(part)
  else
    self.dataQ:pushBack(data)
  end
end

function MD.new(size, sock)

  local q = Q.new(size)
  local dec = binary.Decoder.new(q)

  local result = {
    sock = sock,
    dataQ = q,
    decoder = dec,
    channelId = 0
  }

  setmetatable(result, MD)

  return result
end

return MD
