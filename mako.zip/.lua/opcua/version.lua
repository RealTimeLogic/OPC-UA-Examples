return {
  ApplicationUri = "urn:realtimelogic:OPC UA Server",
  ProductUri = "http://realtimelogic.com",
  ProductName = "Real Time Logic OPC UA Server",
  ApplicationName = "Real Time Logic OPC UA Server",
  ManufacturerName = "Real Time Logic",
  Version = "0.1",
  BuildNumber = "28"
}
