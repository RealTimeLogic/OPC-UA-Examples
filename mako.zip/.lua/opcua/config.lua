local function GetDefConfig()
  return {
    listenPort = 4841,
    listenAddress = "*",

    endpointUrl = "opc.tcp:://localhost:4841",
    applicationName = 'RealTimeLogic OPCUA',
    applicationUri = "urn:realtimelogic:opcua-lua",
    productUri = "urn:realtimelogic:opcua-lua",

    securityPolicyUri = "http://opcfoundation.org/UA/SecurityPolicy#None",
    certificate = {},
    certificateThumbprint = {},

    bufSize = 16384,

    logging = {
      socket = {
        dbgOn = false,
        infOn = true,
        errOn = true
      },
      binary = {
        dbgOn = false,
        infOn = true,
        errOn = true
      },
      services = {
        dbgOn = false,
        infOn = true,
        errOn = true
      }
    },
  }
end

local function MergeConfig(config, diff)
  local result = config
  for k,v in pairs(diff) do
    local pv = config[k]
    assert(type(pv) == type(v), "Invalid type of configuration parameter '"..k.."': required "..type(pv) .. " but got " .. type(v))
    if type(pv) == 'table' then
      result[k] = MergeConfig(pv, v)
    else
      result[k] = v
    end
  end

  return result
end


local function merge(patch, base)
  local def = base == nil and GetDefConfig() or base
  if patch ~= nil then
    return MergeConfig(def, patch)
  end
  return def
end

return merge
