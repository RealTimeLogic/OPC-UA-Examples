local ua = require("opcua.api")
local tools = ua.Tools

-- local D = ua.trace.dbg
local I = ua.trace.inf
local E = ua.trace.err

local BadCommunicationError = 0x80050000

local fmt = string.format

local function newOutput(logging, sock)
    local output = {
      send = function(_, data)
        -- local dbgOn = logging.dbgOn
        local infOn = logging.infOn
        local errOn = logging.errOn

        if infOn then I(fmt("socket | %s sending %d bytes to client", sock, #data)) end
        local done, err = sock:write(data)
        if done == true then
          if infOn then I(fmt("socket | %s Data sent", sock)) end
        else
          if errOn then E(fmt("socket | %s Tcp error: ", sock, err)) end
          error(BadCommunicationError)
        end
      end,

      receive = function(_)
        -- local dbgOn = logging.dbgOn
        local infOn = logging.infOn
        local errOn = logging.errOn

        if infOn then I(fmt("socket | %s reading data from socket", sock)) end
        local data, err = sock:read()
        if data ~= nil then
          return data
        end
        if errOn then E(fmt("socket | %s Tcp error: ", sock, err)) end
        error(BadCommunicationError)
      end
  }
  return output
end

local C={} -- OpcUa Client
C.__index=C
function C:connect(clientConfig)
  assert(clientConfig)
  local mergeConf = require("opcua.config")
  local config = mergeConf(clientConfig)
  if #config.certificate == 0 then
    config.certificate = nil
  end

  if #config.certificateThumbprint == 0 then
    config.certificateThumbprint = nil
  end

  self.config = config

  local infOn = config.logging.services.infOn
  local errOn = config.logging.services.errOn

  if infOn then I("Connecting to endpoint: "..config.endpointUrl) end
  local s,h,p,_ = ua.parseUrl(config.endpointUrl)
  if s ~= "opc.tcp" then
    error("Unknown protocol scheme '"..s.."'")
  end

  if infOn then I("conecting to host '"..h.."' port '"..p.."'") end
  local sock, err = ba.socket.connect(h, p)
  if err ~= nil then
    if errOn then E("error "..err) end
    error (err)
  end

  if infOn then I("connected") end

  self.sock = sock
  local out = newOutput(config.logging.socket, sock)
  local services = require("opcua.binary.client").new(config, out)
  if infOn then I("Saying hello to server") end
  local ack = services:helloServer(config.endpointUrl)

  if infOn then
    I("Acknowledged: ProtocolVersion='"..ack.protocolVersion.."' ReceiveBufferSize='"..ack.receiveBufferSize..
       "' SendBufferSize='"..ack.sendBufferSize.."' MaxMessageSize: '"..ack.maxMessageSize..
       "' MaxChunkCount: '"..ack.maxChunkCount.."'")
  end

  self.services = services

  return ack
end

function C:openSecureChannel(timeoutMs)
  local infOn = self.config.logging.services.infOn
  if infOn then I("Opening secure channel") end

  local config = self.config
  local securityParams = {
    securityPolicy = config.securityPolicy,
    certificate = config.certificate,
    certificateThumbprint = config.certificateThumbprint,

    clientProtocolVersion = 0,
    requestType = ua.Types.SecurityTokenRequestType.Issue,
    securityMode = ua.Types.MessageSecurityMode.None,
    clientNonce = "",
    requestedLifetime = timeoutMs
  }

  local secureChannel = self.services:openSecureChannel(securityParams)
  if infOn then
    I("SecureChannel: ChannelId="..secureChannel.securityToken.channelId.." TokenId="..secureChannel.securityToken.tokenId..
      " CreatedAt="..secureChannel.securityToken.createdAt.." RevisedLifetime="..secureChannel.securityToken.revisedLifetime)
  end

  return secureChannel
end

function C:createSession(name, timeoutMs)
  local infOn = self.config.logging.services.infOn

  if infOn then I("Creating session"..name.." timeout"..timeoutMs) end

  local sessionParams = {
    applicationName = self.config.applicationName,
    applicationType = ua.Types.ApplicationType.Client,
    applicationUri = self.config.applicationUri,
    productUri = self.config.productUri,
    sessionName = name,
    endpointUrl = self.config.endpointUrl,
    serverUri = nil,
    sessionTimeout = timeoutMs,
    clientCertificate = self.config.ClientCertificate,
    clientNonce = {
      0,0,0,0, 0,0,0,0,
      0,0,0,0, 0,0,0,0,
      0,0,0,0, 0,0,0,0,
      0,0,0,0, 0,0,0,0,
    },
  }


  local response = self.services:createSession(sessionParams)
  if infOn then
    I("SessionId='"..response.sessionId.."' MaxRequestMessageSize="..response.maxRequestMessageSize.." AuthenticationToken='"..response.authenticationToken.."' RevisedSessionTimeout="..response.revisedSessionTimeout)
  end

  local policyId
  for _,endpoint in ipairs(response.serverEndpoints) do
    for _,token in ipairs(endpoint.userIdentityTokens) do
      if token.tokenType == 0 then
        policyId = token.policyId
        break
      end
    end

    if policyId ~= nil then
      break
    end
  end

  self.services.sessionId = response.sessionId
  self.services.sessionAuthToken = response.authenticationToken
  if infOn then I("Activating session") end

  local activateParams = {
    clientSignature = {
      algorithm = nil,
      signature = nil
    },
    clientSoftwareCertificates = {},
    locales = {"en"},
    userIdentityToken = tools.createAnonymousToken(policyId),
    userTokenSignature = {}
  }

  response = self.services:activateSession(activateParams)
  if type(response.activationResultCodes) == 'table' then
    for _,code in ipairs(response.activationResultCodes) do
      if code ~= 0 then
        error(code)
      end
    end
  end
  if infOn then I("Session activated") end
end

function C:browse(browseParams)
  local infOn = self.config.logging.services.infOn
  if infOn then I("Browsing nodes") end
  local resp = self.services:browse(browseParams)
  local results = resp.results

  for i,res in pairs(results) do
    for j,ref in pairs(res.references) do
      ref.nodeId = ref.nodeId
      ref.referenceTypeId = ref.referenceTypeId
      if infOn then
        I("Reference["..i..","..j.."]:  NodeId='"..ref.nodeId.."' ReferenceId='"..ref.referenceTypeId..
          "' IsForward='"..ref.isForward.."' BrowseName: ns="..ref.browseName.ns..";name="..ref.browseName.name..
          " NodeClass="..ref.nodeClass)
      end
    end
  end

  return resp
end

function C:read(readParams)
  local infOn = self.config.logging.services.infOn
  if infOn then I("Reading attributes") end

  if readParams.maxAge == nil then
    readParams.maxAge = 0
  end

  if readParams.timestampsToReturn == nil then
    readParams.timestampsToReturn = 0
  end

  for _,v in pairs(readParams.nodesToRead) do
    if v.indexRange == nil then
      v.indexRange = ""
    end
    if v.dataEncoding == nil then
      v.dataEncoding = {ns=0}
    end
  end

  local resp = self.services:read(readParams)
  for i,result in ipairs(resp.results) do
    result.attributeId = readParams.nodesToRead[i].attributeId
  end

  return resp
end

function C:addNodes(params)

  for _,node in pairs(params.nodesToAdd) do
    local body = node.nodeAttributes.body
    local nodeClass = node.nodeClass
    if nodeClass == ua.Types.NodeClass.Variable then
      body.specifiedAttributes = ua.Types.VariableAttributesMask
    elseif nodeClass == ua.Types.NodeClass.Object then
      body.specifiedAttributes = ua.Types.ObjectAttributesMask
    end
  end

  return self.services:addNodes(params)
end

function C:closeSession()
  local infOn = self.config.logging.services.infOn
  if infOn then I("Closing session") end
  local closeSessionParams = {
    deleteSubscriptions = 1
  }

  self.services:closeSession(closeSessionParams)
  if infOn then I("Session closed") end
end

function C:disconnect()
  local infOn = self.config.logging.services.infOn
  if infOn then I("Closing secure channel") end
  self.services:closeSecureChannel()
  if infOn then I("Closing socket") end
  self.sock:close()
  self.services = nil
end

local function NewUaClient()
  local c = {}
  setmetatable(c, C)
  return c
end

return {new=NewUaClient}
