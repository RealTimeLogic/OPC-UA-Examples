local ua = require("opcua.api")
local tools = require("opcua.binary.tools")

local D = ua.trace.dbg
local I = ua.trace.inf
local E = ua.trace.err

local BadCommunicationError = 0x80050000

local fmt = string.format

local Output = {
  send = function(self, data)
    local dbgOn = self.logging.dbgOn
    local infOn = self.logging.infOn
    local errOn = self.logging.errOn

    if infOn then I(fmt("socket | %s sending %d bytes to client", self.sock, #data)) end
    if dbgOn  then
      D("socket | ------------ SENDING DATA --------------------")
      tools.hexPrint(data, function(msg) D("socket | "..msg) end)
      D("socket | ----------------------------------------------")
    end
    local done, err = self.sock:write(data)
    if done == true then
      if infOn then I(fmt("socket | %s Data sent", self.sock)) end
      return
    end
    if errOn then E(fmt("socket | %s Tcp error: ", self.sock, err)) end
    error(BadCommunicationError)
  end,

  receive = function(self)
    local dbgOn = self.logging.dbgOn
    local infOn = self.logging.infOn
    local errOn = self.logging.errOn

    if infOn then I(fmt("socket | %s reading data", self.sock)) end
    local data, err = self.sock:read()
    if data == nil then
      if errOn then E(fmt(string.format("socket | %s error %s", self.sock, err))) end
      error(BadCommunicationError)
    end
    if infOn then I(fmt("socket | %s received %d bytes", self.sock, #data)) end
    if dbgOn  then
      D("socket | ------------ NEW DATA RECEIVED----------------")
      tools.hexPrint(data, function(msg) D("socket | "..msg) end)
      D("socket | ----------------------------------------------")
    end
    return data
  end
}

Output.__index = Output
local function newOutput(logging, sock)
  local result = {
    sock = sock,
    logging = logging
  }
  setmetatable(result, Output)
  return result;
end


local C={} -- OpcUa Client
C.__index=C
function C:connect(clientConfig)
  local mergeConf = require("opcua.config")
  local config = mergeConf(clientConfig)
  if #config.certificate == 0 then
    config.certificate = nil
  end

  if #config.certificateThumbprint == 0 then
    config.certificateThumbprint = nil
  end

  self.config = config

  local infOn = config.logging.services.infOn
  local errOn = config.logging.services.errOn

  if infOn then I("Connecting to endpoint: "..config.endpointUrl) end
  local s,h,p,_ = ua.parseUrl(config.endpointUrl)
  if s ~= "opc.tcp" then
    error("Unknown protocol scheme '"..s.."'")
  end

  if infOn then I("conecting to host '"..h.."' port '"..p.."'") end
  local sock, err = ba.socket.connect(h, p)
  if err ~= nil then
    if errOn then E("error "..err) end
    error (err)
  end

  if infOn then I("connected") end

  self.sock = sock
  local out = newOutput(config.logging.socket, sock)
  local services = require("opcua.binary.client").new(config, out)
  if infOn then I("Saying hello to server") end
  local ack = services:helloServer(config.endpointUrl)

  if infOn then
    I("Acknowledged: ProtocolVersion='"..ack.protocolVersion.."' ReceiveBufferSize='"..ack.receiveBufferSize..
       "' SendBufferSize='"..ack.sendBufferSize.."' MaxMessageSize: '"..ack.maxMessageSize..
       "' MaxChunkCount: '"..ack.maxChunkCount.."'")
  end

  self.services = services

  return ack
end

function C:openSecureChannel(timeoutMs)
  if infOn then I("Opening secure channel") end

  local config = self.config
  local securityParams = {
    securityPolicy = config.securityPolicy,
    certificate = config.certificate,
    certificateThumbprint = config.certificateThumbprint,

    clientProtocolVersion = 0,
    requestType = ua.Types.SecurityTokenRequestType.Issue,
    securityMode = ua.Types.MessageSecurityMode.None,
    clientNonce = "",
    requestedLifetime = timeoutMs
  }

  local secureChannel = self.services:openSecureChannel(securityParams)
  if infOn then
    I("SecureChannel: ChannelId="..secureChannel.securityToken.channelId.." TokenId="..secureChannel.securityToken.tokenId..
      " CreatedAt="..secureChannel.securityToken.createdAt.." RevisedLifetime="..secureChannel.securityToken.revisedLifetime)
  end

  return secureChannel
end

function C:createSession(name, timeoutMs)
  local infOn = self.config.logging.services.infOn

  if infOn then I("Creating session"..name.." timeout"..timeoutMs) end

  local sessionParams = {
    applicationName = self.config.applicationName,
    applicationType = ua.Types.ApplicationType.Client,
    applicationUri = self.config.applicationUri,
    productUri = self.config.productUri,
    sessionName = name,
    endpointUrl = self.config.endpointUrl,
    serverUri = nil,
    sessionTimeout = timeoutMs,
    clientCertificate = self.config.ClientCertificate,
    clientNonce = {
      0,0,0,0, 0,0,0,0,
      0,0,0,0, 0,0,0,0,
      0,0,0,0, 0,0,0,0,
      0,0,0,0, 0,0,0,0,
    },
  }


  local response = self.services:createSession(sessionParams)
  if infOn then
    I("SessionId='"..response.sessionId.."' MaxRequestMessageSize="..response.maxRequestMessageSize.." AuthenticationToken='"..response.authenticationToken.."' RevisedSessionTimeout="..response.revisedSessionTimeout)
  end

  self.services.sessionId = response.sessionId
  self.services.sessionAuthToken = response.authenticationToken
  if infOn then I("Activating session") end

  local activateParams = {
    clientSignature = {
      algorithm = nil,
      signature = nil
    },
    clientSoftwareCertificates = {},
    locales = {"en"},
    userIdentityToken = "anonymous"
  }

  response = self.services:activateSession(activateParams)
  if type(response.activationResultCodes) == 'table' then
    for _,code in ipairs(response.activationResultCodes) do
      if code ~= 0 then
        error(code)
      end
    end
  end
  if infOn then I("Session activated") end
end

function C:browse(nodeId)
  local infOn = self.config.logging.services.infOn

  local browseParams = {
    nodesToBrowse = {
      {
        nodeId = nodeId,
        referenceTypeId = "i=33",
        browseDirection = ua.Types.BrowseDirection.Forward,
        nodeClass = ua.Types.NodeClass.Unspecified,
        resultMask = ua.Types.BrowseResultMask.All,
        includeSubtypes = true,
      }
    },
  }

  if infOn then I("Browsing node '"..nodeId.."'") end
  local results = self.services:browse(browseParams)

  for i,res in pairs(results) do
    for j,ref in pairs(res.references) do
      ref.nodeId = ref.nodeId
      ref.referenceTypeId = ref.referenceTypeId
      if infOn then
        I("Reference["..i..","..j.."]:  NodeId='"..ref.nodeId.."' ReferenceId='"..ref.referenceTypeId..
          "' IsForward='"..ref.isForward.."' BrowseName: ns="..ref.browseName.ns..";name="..ref.browseName.name..
          " NodeClass="..ref.nodeClass)
      end
    end
  end

  return results
end

function C:read(nodeId)
  local infOn = self.config.logging.services.infOn
  if infOn then I("Reading attributes of node '"..nodeId.."'") end

  local attr = ua.Types.AttributeId

  local nodes = {}
  for _,v in pairs(ua.Types.AttributeId) do
    if v > attr.Invalid and v < attr.Max then
      table.insert(nodes, { nodeId = nodeId, attributeId = v })
    end
  end

  local results = self.services:read(nodes)

  for i,result in ipairs(results) do
    result.attributeId = nodes[i].attributeId
  end

  return results
end

function C:closeSession()
  local infOn = self.config.logging.services.infOn
  if infOn then I("Closing session") end
  local closeSessionParams = {
    deleteSubscriptions = 1
  }

  self.services:closeSession(closeSessionParams)
  if infOn then I("Session closed") end
end

function C:disconnect()
  local infOn = self.config.logging.services.infOn
  if infOn then I("Closing secure channel") end
  self.services:closeSecureChannel()
  if infOn then I("Closing socket") end
  self.sock:close()
  self.services = nil
end

  local function NewUaClient()
  local c = {}
  setmetatable(c, C)
  return c
end

return {new=NewUaClient}
