if ba == nil then
  ba = {
    b64decode = require"base64".decode,
    b64encode = require"base64".encode,
    bytearray = require("opcua.binary.table_array")
  }
end
