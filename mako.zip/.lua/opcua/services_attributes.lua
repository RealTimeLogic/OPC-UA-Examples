--
-- Functions for creating datavalues
--
local ua = require("opcua.api")
local s = ua.Status

local BadAttributeIdInvalid = s.BadAttributeIdInvalid
local BadTypeMismatch = s.BadTypeMismatch
local BadNodeClassInvalid = s.BadNodeClassInvalid

local t = ua.Tools
local AttributeId = ua.Types.AttributeId

local Boolean = "i=1"
local SByte = "i=2"
local Byte = "i=3"
local Int16 = "i=4"
local UInt16 = "i=5"
local Int32 = "i=6"
local UInt32 = "i=7"
local Int64 = "i=8"
local UInt64 = "i=9"
local Float = "i=10"
local Double = "i=11"
local String = "i=12"
local DateTime = "i=13"
local Guid = "i=14"
local ByteString = "i=15"
local XmlElement = "i=16"
local NodeId = "i=17"
local ExpandedNodeId = "i=18"
local StatusCode = "i=19"
local QualifiedName = "i=20"
local LocalizedText = "i=21"
--local Structure = "i=22"
local DataValue = "i=23"
local BaseDataType = "i=24"
local Variant = "i=24"
local DiagnosticInfo = "i=25"
--local Number = "i=26"
--local Integer = "i=27"
local HasSubtype = "i=45"
local ExtensionObject = "i=22"
local UtcTime = "i=294"

local function createBadAttribute()
  return { statusCode = BadAttributeIdInvalid}
end

local function getValue(attr, dataType)
  assert(type(dataType) == 'string')

  if type(attr) == 'table' and attr.value ~= nil then
    return attr
  end

  if attr == nil then
    return createBadAttribute()
  end

  local variant = {}

  if dataType == Boolean then
    variant.boolean = attr
  elseif dataType == SByte then
    variant.sbyte = attr or 0
  elseif dataType == Byte then
    variant.byte = attr
  elseif dataType == Int16 then
    variant.int16 = attr
  elseif dataType == UInt16 then
    variant.uint16 = attr
  elseif dataType == Int32 then
    variant.int32 = attr
  elseif dataType == UInt32 then
    variant.uint32 = attr
  elseif dataType == Int64 then
    variant.int64 = attr
  elseif dataType == UInt64 then
    variant.uint64 = attr
  elseif dataType == Float then
    variant.float = attr
  elseif dataType == Double then
    variant.double = attr or 0.0
  elseif dataType == String then
    variant.string = attr
  elseif dataType == DateTime or dataType == 294 then
    variant.dateTime = attr
  elseif dataType == Guid then
    variant.guid = attr
  elseif dataType == ByteString then
    variant.byteString = attr
  elseif dataType == XmlElement then
    return createBadAttribute()
  elseif dataType == NodeId then
    variant.nodeId = attr
  elseif dataType == ExpandedNodeId then
    variant.expandedNodeId = attr
  elseif dataType == StatusCode then
    variant.statusCode = attr
  elseif dataType == QualifiedName then
    if t.qualifiedNameValid(attr) then
      variant.qualifiedName = attr
    else
      variant.qualifiedName = {
        ns = 0,
        name = attr
      }
    end
  elseif dataType == LocalizedText then
    variant.localizedText = {}
    if type(attr) == "string" then
      variant.localizedText = {
        text = attr,
        locale = "en"
      }
    else
      variant.localizedText = attr
    end
  elseif dataType == ExtensionObject then
    variant.extensionObject = attr
  elseif dataType == DataValue then
    return createBadAttribute()
  elseif dataType == Variant then
    return createBadAttribute()
  elseif dataType == DiagnosticInfo then
    return createBadAttribute()
  else
    return createBadAttribute()
  end

  return {
    value = variant,
    statusCode = 0
  }
end

local function getCommonAttribute(attrs, attrId)
  local attr = attrs[attrId]
  local val
  if attrId == AttributeId.NodeId then
    val = getValue(attr, NodeId)
  elseif attrId == AttributeId.NodeClass then
    val = getValue(attr, Int32)
  elseif attrId == AttributeId.BrowseName then
    val = getValue(attr, QualifiedName)
  elseif attrId == AttributeId.DisplayName then
    val = getValue(attr, LocalizedText)
  elseif attrId == AttributeId.Description then
    val = getValue(attr, LocalizedText)
  elseif attrId == AttributeId.WriteMask then
    val = getValue(attr, UInt32)
  elseif attrId == AttributeId.UserWriteMask then
    val = getValue(attr, UInt32)
  else
    return createBadAttribute()
  end
  return val
end

local function getObjectAttribute(attrs, attrId, nodeset)
  if attrId == AttributeId.EventNotifier then
    return getValue(attrs[attrId] or 0, Byte)
  else
    return getCommonAttribute(attrs, attrId, nodeset)
  end
end

local function getRefTypeAttribute(attrs, attrId, nodeset)
  if attrId == AttributeId.IsAbstract then
    return getValue(attrs[attrId] or 0, Boolean)
  elseif attrId == AttributeId.Symmetric then
    return getValue(attrs[attrId] or 0, Boolean)
  elseif attrId == AttributeId.InverseName then
    return getValue(attrs[attrId], LocalizedText)
  else
    return getCommonAttribute(attrs, attrId, nodeset)
  end
end

local function getVariableAttribute(attrs, attrId, nodeset)
  if attrId == AttributeId.Value then
    if attrs.valueSource ~= nil then
      return getValue(attrs.valueSource(), attrs[AttributeId.DataType])
    else
      return getValue(attrs[attrId], attrs[AttributeId.DataType])
    end
  elseif attrId == AttributeId.DataType then
    return getValue(attrs[attrId], NodeId)
  elseif attrId == AttributeId.Rank then
    return getValue(attrs[attrId], Int32)
  elseif attrId == AttributeId.ArrayDimensions then
    return getValue(attrs[attrId], UInt32)
  elseif attrId == AttributeId.AccessLevel then
    return getValue(attrs[attrId], Byte)
  elseif attrId == AttributeId.UserAccessLevel then
    return getValue(attrs[attrId], Byte)
  elseif attrId == AttributeId.MinimumSamplingInterval then
    return getValue(attrs[attrId], Double)
  elseif attrId == AttributeId.Historizing then
    return getValue(attrs[attrId] or false, Boolean)
  elseif attrId == AttributeId.AccessLevelEx then
    return getValue(attrs[attrId], UInt32)
  else
    return getCommonAttribute(attrs, attrId, nodeset)
  end
end

local function checkDataType(val, dataType, nodeset)
  if val == nil then
    return
  end

  if type(dataType) == 'string' then
    -- if datatype is a node id in string representation
    local tt = ua.NodeId.fromString(dataType).id
    while tt >= AttributeId.Max and nodeset ~= nil do
      local n = nodeset:getNode(dataType)
      if n == nil then return s.NodeIdUnknown end
      for _,v in ipairs(n.refs) do
        if v[2] == HasSubtype and v[3] == 0 then
          dataType = v[1]
          tt = ua.NodeId.fromString(dataType).id
          break
        end
      end
    end
    if dataType == BaseDataType then
      if not t.variantValid(val)  then
        error(BadTypeMismatch)
      end
    end
  end

  if type(dataType) == 'table' and dataType.id ~= nil then
    assert(dataType.ns == nil or dataType.ns == 0, "Supported only builtin variant types from ns=0.")
  end

  if dataType == UtcTime then
    dataType = DateTime
  end

  local vt = t.getVariantType(val)
  local isValid = (dataType == "i=24" or vt == dataType or vt == ExtensionObject) and t.variantValid(val)
  if isValid == false then
    error(BadTypeMismatch)
  end
end


local function checkCommonAttribute(attrs, attrId, nodeset)
  local val = attrs[attrId]
  if attrId == AttributeId.NodeId then
    checkDataType(val, NodeId, nodeset)
  elseif attrId == AttributeId.NodeClass then
    checkDataType(val, Int32, nodeset)
  elseif attrId == AttributeId.BrowseName then
    checkDataType(val, QualifiedName, nodeset)
  elseif attrId == AttributeId.DisplayName then
    checkDataType(val, LocalizedText, nodeset)
  elseif attrId == AttributeId.Description then
    checkDataType(val, LocalizedText, nodeset)
  elseif attrId == AttributeId.WriteMask then
    checkDataType(val, UInt32, nodeset)
  elseif attrId == AttributeId.UserWriteMask then
    checkDataType(val, UInt32, nodeset)
  end
  return createBadAttribute()
end

local function checkObjectAttribute(attrs, attrId, nodeset)
  if attrId == AttributeId.EventNotifier then
    checkDataType(attrs[AttributeId.EventNotifier], Byte, nodeset)
  else
    checkCommonAttribute(attrs, attrId, nodeset)
  end
end

--[[
  TODO
local function CheckRefTypeAttribute(attrs, attrId)
  if attrId == AttributeId.IsAbstract then
    checkDataType(attrs[AttributeId.IsAbstract], Boolean)
  elseif attrId == AttributeId.Symmetric then
    checkDataType(attrs[AttributeId.Symmetric], Boolean)
  elseif attrId == AttributeId.InverseName then
    checkDataType(attrs[AttributeId.InverseName], LocalizedText)
  else
    checkCommonAttribute(attrs, attrId, nodeset)
  end
end
--]]

local function checkVariableAttribute(attrs, attrId, val, nodeset)
  if attrId == AttributeId.Value then
    if not t.dataValueValid(val) then
        error(BadAttributeIdInvalid)
    end
    checkDataType(val.value, attrs[AttributeId.DataType], nodeset)
  elseif attrId == AttributeId.DataType then
    checkDataType(val, NodeId)
  elseif attrId == AttributeId.ValueRank then
    checkDataType(val, Int32)
  elseif attrId == AttributeId.ArrayDimensions then
    checkDataType(val, UInt32)
  elseif attrId == AttributeId.AccessLevel then
    checkDataType(val, Byte)
  elseif attrId == AttributeId.UserAccessLevel then
    checkDataType(val, Byte)
  elseif attrId == AttributeId.MinimumSamplingInterval then
    checkDataType(val, Double)
  elseif attrId == AttributeId.Historizing then
    checkDataType(val, Boolean)
  elseif attrId == AttributeId.AccessLevelEx then
    checkDataType(val, UInt32)
  else
    checkCommonAttribute(attrs, attrId)
  end
end

return {
  getAttributeValue = function (attrs, attrId)
    local nodeClass = attrs[AttributeId.NodeClass]
    local val
    if type(nodeClass) ~= 'number' or (nodeClass & (nodeClass - 1) ~= 0) then
      error(BadNodeClassInvalid)
    end

    if nodeClass == ua.Types.NodeClass.Object then
      val = getObjectAttribute(attrs, attrId)
    elseif nodeClass == ua.Types.NodeClass.ReferenceType then
      val = getRefTypeAttribute(attrs, attrId)
    elseif nodeClass == ua.Types.NodeClass.Variable then
      val = getVariableAttribute(attrs, attrId)
    else
      val = getCommonAttribute(attrs, attrId)
    end

    return val
  end,

  checkAttributeValue = function(attrs, attrId, dataValue, nodeset)
    if attrId < 0 or attrId > AttributeId.Max then
      error(BadAttributeIdInvalid)
    end

    local nodeClass = attrs[AttributeId.NodeClass]
    if nodeClass == ua.Types.NodeClass.Variable then
      checkVariableAttribute(attrs, attrId, dataValue, nodeset)
    elseif nodeClass == ua.Types.NodeClass.Object then
      checkObjectAttribute(attrs, attrId, dataValue)
    end
  end,

  checkDataType = checkDataType
}
