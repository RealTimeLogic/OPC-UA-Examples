-- format :
--   attrs array of attributes. numeric index is the attribute id.
--   refs array of triples: {target_node_id, reference_type_id, is_forward}
local n = {}
n["i=2254"]={
attrs={'i=2254',2,{ns=0,name='ServerArray'},'ServerArray','The list of server URIs used by the server.',[14]='i=12',[15]=1,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2253","i=46",0}}}
n["i=2255"]={
attrs={'i=2255',2,{ns=0,name='NamespaceArray'},'NamespaceArray','The list of namespace URIs used by the server.',[14]='i=12',[15]=1,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2253","i=46",0}}}
n["i=2256"]={
attrs={'i=2256',2,{ns=0,name='ServerStatus'},'ServerStatus','The current status of the server.',[14]='i=862',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2257","i=47",1},{"i=2258","i=47",1},{"i=2259","i=47",1},{"i=2260","i=47",1},{"i=2992","i=47",1},{"i=2993","i=47",1},{"i=2253","i=47",0}}}
n["i=2267"]={
attrs={'i=2267',2,{ns=0,name='ServiceLevel'},'ServiceLevel','A value indicating the level of service the server can provide. 255 indicates the best.',[14]='i=3',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2253","i=46",0}}}
n["i=2994"]={
attrs={'i=2994',2,{ns=0,name='Auditing'},'Auditing','A flag indicating whether the server is currently generating audit events.',[14]='i=1',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2253","i=46",0}}}
n["i=2268"]={
attrs={'i=2268',1,{ns=0,name='ServerCapabilities'},'ServerCapabilities','Describes capabilities supported by the server.',[12]=0},
refs={{"i=2269","i=46",1},{"i=2271","i=46",1},{"i=2272","i=46",1},{"i=2735","i=46",1},{"i=2736","i=46",1},{"i=2737","i=46",1},{"i=3704","i=46",1},{"i=11702","i=46",1},{"i=11703","i=46",1},{"i=11704","i=47",1},{"i=2996","i=47",1},{"i=2997","i=47",1},{"i=2253","i=47",0}}}
n["i=2274"]={
attrs={'i=2274',1,{ns=0,name='ServerDiagnostics'},'ServerDiagnostics','Reports diagnostics about the server.',[12]=0},
refs={{"i=2275","i=47",1},{"i=2289","i=47",1},{"i=2290","i=47",1},{"i=3706","i=47",1},{"i=2294","i=46",1},{"i=2253","i=47",0}}}
n["i=2295"]={
attrs={'i=2295',1,{ns=0,name='VendorServerInfo'},'VendorServerInfo','Server information provided by the vendor.',[12]=0},
refs={{"i=2253","i=47",0}}}
n["i=2296"]={
attrs={'i=2296',1,{ns=0,name='ServerRedundancy'},'ServerRedundancy','Describes the redundancy capabilities of the server.',[12]=0},
refs={{"i=3709","i=46",1},{"i=11312","i=46",1},{"i=11313","i=46",1},{"i=11314","i=46",1},{"i=2253","i=47",0}}}
n["i=11715"]={
attrs={'i=11715',1,{ns=0,name='Namespaces'},'Namespaces','Describes the namespaces supported by the server.',[12]=0},
refs={{"i=2253","i=47",0}}}
n["i=11492"]={
attrs={'i=11492',4,{ns=0,name='GetMonitoredItems'},'GetMonitoredItems',[21]=0,[22]=0},
refs={{"i=11493","i=46",1},{"i=11494","i=46",1},{"i=2253","i=47",0}}}
n["i=2253"]={
attrs={'i=2253',1,{ns=0,name='Server'},'Server',[12]=1},
refs={{"i=2254","i=46",1},{"i=2255","i=46",1},{"i=2256","i=47",1},{"i=2267","i=46",1},{"i=2994","i=46",1},{"i=2268","i=47",1},{"i=2274","i=47",1},{"i=2295","i=47",1},{"i=2296","i=47",1},{"i=11715","i=47",1},{"i=11492","i=47",1}}}
n["i=2257"]={
attrs={'i=2257',2,{ns=0,name='StartTime'},'StartTime',[14]='i=294',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2256","i=47",0}}}
n["i=2258"]={
attrs={'i=2258',2,{ns=0,name='CurrentTime'},'CurrentTime',[14]='i=294',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2256","i=47",0}}}
n["i=2259"]={
attrs={'i=2259',2,{ns=0,name='State'},'State',[14]='i=852',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2256","i=47",0}}}
n["i=2260"]={
attrs={'i=2260',2,{ns=0,name='BuildInfo'},'BuildInfo',[14]='i=338',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2262","i=47",1},{"i=2263","i=47",1},{"i=2261","i=47",1},{"i=2264","i=47",1},{"i=2265","i=47",1},{"i=2266","i=47",1},{"i=2256","i=47",0}}}
n["i=2992"]={
attrs={'i=2992',2,{ns=0,name='SecondsTillShutdown'},'SecondsTillShutdown',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2256","i=47",0}}}
n["i=2993"]={
attrs={'i=2993',2,{ns=0,name='ShutdownReason'},'ShutdownReason',[14]='i=21',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2256","i=47",0}}}
n["i=2262"]={
attrs={'i=2262',2,{ns=0,name='ProductUri'},'ProductUri',[14]='i=12',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2260","i=47",0}}}
n["i=2263"]={
attrs={'i=2263',2,{ns=0,name='ManufacturerName'},'ManufacturerName',[14]='i=12',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2260","i=47",0}}}
n["i=2261"]={
attrs={'i=2261',2,{ns=0,name='ProductName'},'ProductName',[14]='i=12',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2260","i=47",0}}}
n["i=2264"]={
attrs={'i=2264',2,{ns=0,name='SoftwareVersion'},'SoftwareVersion',[14]='i=12',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2260","i=47",0}}}
n["i=2265"]={
attrs={'i=2265',2,{ns=0,name='BuildNumber'},'BuildNumber',[14]='i=12',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2260","i=47",0}}}
n["i=2266"]={
attrs={'i=2266',2,{ns=0,name='BuildDate'},'BuildDate',[14]='i=294',[15]=0,[17]=0,[18]=0,[19]=1000.0,[20]=0},
refs={{"i=2260","i=47",0}}}
n["i=2269"]={
attrs={'i=2269',2,{ns=0,name='ServerProfileArray'},'ServerProfileArray','A list of profiles supported by the server.',[14]='i=12',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=2271"]={
attrs={'i=2271',2,{ns=0,name='LocaleIdArray'},'LocaleIdArray','A list of locales supported by the server.',[14]='i=295',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=2272"]={
attrs={'i=2272',2,{ns=0,name='MinSupportedSampleRate'},'MinSupportedSampleRate','The minimum sampling interval supported by the server.',[14]='i=290',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=2735"]={
attrs={'i=2735',2,{ns=0,name='MaxBrowseContinuationPoints'},'MaxBrowseContinuationPoints','The maximum number of continuation points for Browse operations per session.',[14]='i=5',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=2736"]={
attrs={'i=2736',2,{ns=0,name='MaxQueryContinuationPoints'},'MaxQueryContinuationPoints','The maximum number of continuation points for Query operations per session.',[14]='i=5',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=2737"]={
attrs={'i=2737',2,{ns=0,name='MaxHistoryContinuationPoints'},'MaxHistoryContinuationPoints','The maximum number of continuation points for ReadHistory operations per session.',[14]='i=5',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=3704"]={
attrs={'i=3704',2,{ns=0,name='SoftwareCertificates'},'SoftwareCertificates','The software certificates owned by the server.',[14]='i=344',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=11702"]={
attrs={'i=11702',2,{ns=0,name='MaxArrayLength'},'MaxArrayLength','The maximum length for an array value supported by the server.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=11703"]={
attrs={'i=11703',2,{ns=0,name='MaxStringLength'},'MaxStringLength','The maximum length for a string value supported by the server.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2268","i=46",0}}}
n["i=11704"]={
attrs={'i=11704',1,{ns=0,name='OperationLimits'},'OperationLimits','Defines the limits supported by the server for different operations.',[12]=0},
refs={{"i=11705","i=46",1},{"i=12165","i=46",1},{"i=12166","i=46",1},{"i=11707","i=46",1},{"i=12167","i=46",1},{"i=12168","i=46",1},{"i=11709","i=46",1},{"i=11710","i=46",1},{"i=11711","i=46",1},{"i=11712","i=46",1},{"i=11713","i=46",1},{"i=11714","i=46",1},{"i=2268","i=47",0}}}
n["i=2996"]={
attrs={'i=2996',1,{ns=0,name='ModellingRules'},'ModellingRules','A folder for the modelling rules supported by the server.',[12]=0},
refs={{"i=2268","i=47",0}}}
n["i=2997"]={
attrs={'i=2997',1,{ns=0,name='AggregateFunctions'},'AggregateFunctions','A folder for the real time aggregates supported by the server.',[12]=0},
refs={{"i=2268","i=47",0}}}
n["i=11705"]={
attrs={'i=11705',2,{ns=0,name='MaxNodesPerRead'},'MaxNodesPerRead','The maximum number of operations in a single Read request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=12165"]={
attrs={'i=12165',2,{ns=0,name='MaxNodesPerHistoryReadData'},'MaxNodesPerHistoryReadData','The maximum number of operations in a single data HistoryRead request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=12166"]={
attrs={'i=12166',2,{ns=0,name='MaxNodesPerHistoryReadEvents'},'MaxNodesPerHistoryReadEvents','The maximum number of operations in a single event HistoryRead request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11707"]={
attrs={'i=11707',2,{ns=0,name='MaxNodesPerWrite'},'MaxNodesPerWrite','The maximum number of operations in a single Write request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=12167"]={
attrs={'i=12167',2,{ns=0,name='MaxNodesPerHistoryUpdateData'},'MaxNodesPerHistoryUpdateData','The maximum number of operations in a single data HistoryUpdate request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=12168"]={
attrs={'i=12168',2,{ns=0,name='MaxNodesPerHistoryUpdateEvents'},'MaxNodesPerHistoryUpdateEvents','The maximum number of operations in a single event HistoryUpdate request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11709"]={
attrs={'i=11709',2,{ns=0,name='MaxNodesPerMethodCall'},'MaxNodesPerMethodCall','The maximum number of operations in a single Call request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11710"]={
attrs={'i=11710',2,{ns=0,name='MaxNodesPerBrowse'},'MaxNodesPerBrowse','The maximum number of operations in a single Browse request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11711"]={
attrs={'i=11711',2,{ns=0,name='MaxNodesPerRegisterNodes'},'MaxNodesPerRegisterNodes','The maximum number of operations in a single RegisterNodes request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11712"]={
attrs={'i=11712',2,{ns=0,name='MaxNodesPerTranslateBrowsePathsToNodeIds'},'MaxNodesPerTranslateBrowsePathsToNodeIds','The maximum number of operations in a single TranslateBrowsePathsToNodeIds request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11713"]={
attrs={'i=11713',2,{ns=0,name='MaxNodesPerNodeManagement'},'MaxNodesPerNodeManagement','The maximum number of operations in a single AddNodes, AddReferences, DeleteNodes or DeleteReferences request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=11714"]={
attrs={'i=11714',2,{ns=0,name='MaxMonitoredItemsPerCall'},'MaxMonitoredItemsPerCall','The maximum number of operations in a single MonitoredItem related request.',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=11704","i=46",0}}}
n["i=2275"]={
attrs={'i=2275',2,{ns=0,name='ServerDiagnosticsSummary'},'ServerDiagnosticsSummary','A summary of server level diagnostics.',[14]='i=859',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2276","i=47",1},{"i=2277","i=47",1},{"i=2278","i=47",1},{"i=2279","i=47",1},{"i=3705","i=47",1},{"i=2281","i=47",1},{"i=2282","i=47",1},{"i=2284","i=47",1},{"i=2285","i=47",1},{"i=2286","i=47",1},{"i=2287","i=47",1},{"i=2288","i=47",1},{"i=2274","i=47",0}}}
n["i=2289"]={
attrs={'i=2289',2,{ns=0,name='SamplingIntervalDiagnosticsArray'},'SamplingIntervalDiagnosticsArray','A list of diagnostics for each sampling interval supported by the server.',[14]='i=856',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2274","i=47",0}}}
n["i=2290"]={
attrs={'i=2290',2,{ns=0,name='SubscriptionDiagnosticsArray'},'SubscriptionDiagnosticsArray','A list of diagnostics for each active subscription.',[14]='i=874',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2274","i=47",0}}}
n["i=3706"]={
attrs={'i=3706',1,{ns=0,name='SessionsDiagnosticsSummary'},'SessionsDiagnosticsSummary','A summary of session level diagnostics.',[12]=0},
refs={{"i=3707","i=47",1},{"i=3708","i=47",1},{"i=2274","i=47",0}}}
n["i=2294"]={
attrs={'i=2294',2,{ns=0,name='EnabledFlag'},'EnabledFlag','If TRUE the diagnostics collection is enabled.',[14]='i=1',[15]=0,[17]=3,[18]=3,[20]=0},
refs={{"i=2274","i=46",0}}}
n["i=2276"]={
attrs={'i=2276',2,{ns=0,name='ServerViewCount'},'ServerViewCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2277"]={
attrs={'i=2277',2,{ns=0,name='CurrentSessionCount'},'CurrentSessionCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2278"]={
attrs={'i=2278',2,{ns=0,name='CumulatedSessionCount'},'CumulatedSessionCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2279"]={
attrs={'i=2279',2,{ns=0,name='SecurityRejectedSessionCount'},'SecurityRejectedSessionCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=3705"]={
attrs={'i=3705',2,{ns=0,name='RejectedSessionCount'},'RejectedSessionCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2281"]={
attrs={'i=2281',2,{ns=0,name='SessionTimeoutCount'},'SessionTimeoutCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2282"]={
attrs={'i=2282',2,{ns=0,name='SessionAbortCount'},'SessionAbortCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2284"]={
attrs={'i=2284',2,{ns=0,name='PublishingIntervalCount'},'PublishingIntervalCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2285"]={
attrs={'i=2285',2,{ns=0,name='CurrentSubscriptionCount'},'CurrentSubscriptionCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2286"]={
attrs={'i=2286',2,{ns=0,name='CumulatedSubscriptionCount'},'CumulatedSubscriptionCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2287"]={
attrs={'i=2287',2,{ns=0,name='SecurityRejectedRequestsCount'},'SecurityRejectedRequestsCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=2288"]={
attrs={'i=2288',2,{ns=0,name='RejectedRequestsCount'},'RejectedRequestsCount',[14]='i=7',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2275","i=47",0}}}
n["i=3707"]={
attrs={'i=3707',2,{ns=0,name='SessionDiagnosticsArray'},'SessionDiagnosticsArray','A list of diagnostics for each active session.',[14]='i=865',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=3706","i=47",0}}}
n["i=3708"]={
attrs={'i=3708',2,{ns=0,name='SessionSecurityDiagnosticsArray'},'SessionSecurityDiagnosticsArray','A list of security related diagnostics for each active session.',[14]='i=868',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=3706","i=47",0}}}
n["i=3709"]={
attrs={'i=3709',2,{ns=0,name='RedundancySupport'},'RedundancySupport','Indicates what style of redundancy is supported by the server.',[14]='i=851',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2296","i=46",0}}}
n["i=11312"]={
attrs={'i=11312',2,{ns=0,name='CurrentServerId'},'CurrentServerId',[14]='i=12',[15]=0,[17]=0,[18]=0,[20]=0},
refs={{"i=2296","i=46",0}}}
n["i=11313"]={
attrs={'i=11313',2,{ns=0,name='RedundantServerArray'},'RedundantServerArray',[14]='i=853',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2296","i=46",0}}}
n["i=11314"]={
attrs={'i=11314',2,{ns=0,name='ServerUriArray'},'ServerUriArray',[14]='i=12',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=2296","i=46",0}}}
n["i=11493"]={
attrs={'i=11493',2,{ns=0,name='InputArguments'},'InputArguments',[13]={value={ExtensionObject=nil}},[14]='i=296',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=11492","i=46",0}}}
n["i=11494"]={
attrs={'i=11494',2,{ns=0,name='OutputArguments'},'OutputArguments',[13]={value={ExtensionObject=nil}},[14]='i=296',[15]=1,[17]=0,[18]=0,[20]=0},
refs={{"i=11492","i=46",0}}}
return n
