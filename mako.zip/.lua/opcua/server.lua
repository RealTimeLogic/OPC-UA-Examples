local S = {}
S.__index = S

local mergeConf = require("opcua.config")

function S:initialize(initAddons)
  -- services responsible for buisness logic: sessions, address space etc.
  self.services = require("opcua.services").new(self.Config)
  self.services:start()

  if type(initAddons) == "function" then
    initAddons(self.services)
  end
end

function S:run()
  -- binary protocol server: parses requests and calls common services
  local binaryServer = require("opcua.binary.server").new(self.Config, self.services)

  local run
  if ba ~= nil then
    run = require("opcua.socket_rtl")
  else
    run = require("opcua.socket_lua")
  end

  run(binaryServer, self.Config)
end

function S.new(config)
  local serverConf = mergeConf(config)
  local srv = {
    Config = serverConf
  }
  setmetatable(srv, S)
  return srv
end

return S
