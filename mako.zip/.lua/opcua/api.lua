local gettime = require("socket").gettime
local function traceLog(level, msg)
  print(gettime(), level, msg)
end

require("opcua.balua")

local ua = {
  newServer = function(config) return require("opcua.server").new(config) end,
  newClient = function() return require("opcua.client").new() end,

  Version = require("opcua.version"),
  Status = require("opcua.status_codes"),
  NodeId = require("opcua.node_id"),
  Types = require("opcua.types"),
  Tools = require("opcua.binary.tools"),

  trace = {
    dbg = function(msg) traceLog("[DBG] ", msg) end,  -- Debug loging print
    inf = function(msg) traceLog("[INF] ", msg) end,  -- Information logging print
    err = function(msg) traceLog("[ERR] ", msg) end   -- Error loging print
  },

  parseUrl = function(endpointUrl)
    local s,h,p,pt
    s,h = string.match(endpointUrl, "^([%a.]+)://([%w.-]+)$")
    if s == nil then
      s,h,p,pt = string.match(endpointUrl, "^([%a.]+)://([%w.-]+):(%d+)$")
    end
    if s == nil then
      s,h,p,pt = string.match(endpointUrl, "^([%a.]+)://([%w.-]+):(%d+)(/.+)$")
    end
    if s == nil then
      error(0x80830000) -- BadTcpEndpointUrlInvalid
    end

    return s,h,tonumber(p),pt
  end
}

return ua
