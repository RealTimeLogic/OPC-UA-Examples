local gettime = require("socket").gettime
local function traceLog(level, msg)
  print(gettime(), level, msg)
end

local ua = {
  newServer = function(config) return require("opcua.server").new(config) end,
  newBinaryClient = function(sock) return require("opcua.binary.client").new(sock) end,

  Version = require("opcua.version"),
  Status = require("opcua.status_codes"),
  NodeId = require("opcua.node_id"),
  Types = require("opcua.types"),
  Tools = require("opcua.binary.tools"),

  trace = {
    dbg = function(msg) traceLog("[DBG] ", msg) end,  -- Debug loging print
    inf = function(msg) traceLog("[INF] ", msg) end,  -- Information logging print
    err = function(msg) traceLog("[ERR] ", msg) end   -- Error loging print
  },

  parseUrl = function(endpointUrl)
    local result = {}
    local params = string.gmatch(endpointUrl, "(%g+)://%g+$")
    for p in params do
      result.Protocol = p
    end

    params = string.gmatch(endpointUrl, "://(%g+):")
    for p in params do
      result.Host = p
    end

    params = string.gmatch(endpointUrl, ":(%d+)$")
    for p in params do
      result.Port = tonumber(p)
    end
    return result
  end
}

return ua
